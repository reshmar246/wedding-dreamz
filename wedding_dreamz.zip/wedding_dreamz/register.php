<?php
       include 'conn.php';
	 
    if(isset($_POST['submit']))
    {
        
        $name=$_POST['name'];
        $place= $_POST['place'];
        $mobile=$_POST['mobile'];
		$email=$_POST['email'];
		
		$var1="SELECT `login_id` FROM `tbl_login` WHERE `username`='$email'";
		$var2=mysqli_query($con,$var1);
		
		if(mysqli_num_rows($var2) == 0)
		{
			
		$password=md5($_POST['password']);
		$cpassword=md5($_POST['cpassword']);
		if ($cpassword == $password) 
		{	
			$sql1="INSERT INTO `tbl_login`(`username`, `password`,`login_role`,`login_status`) VALUES ('$email','$password','2',1)";
			$result1=mysqli_query($con,$sql1);

			$logid="SELECT `login_id` FROM `tbl_login` WHERE `username`='$email'";
			$result2=mysqli_query($con,$logid);
			while($row=mysqli_fetch_array($result2))
			{
				$l=$row["login_id"];
				echo $sql2="INSERT INTO `tbl_registration`(`login_id`,`reg_name`,`reg_place`,`reg_phone`, `reg_status`) VALUES ($l,'$name','$place','$mobile',1)";
				$res = mysqli_query($con, $sql2) or die(mysqli_error());
				echo "<script>alert('Registration Successful');window.location.href='signin.php';</script>";
	
			}
		}
		else 
		{
			echo "<script>alert('Your password does not match');window.location.href='register.php';</script>";
			
		}
		}
		else
		{
			echo "<script>alert('Sorry email is already in use..Please choose a different one..!');window.location.href='register.php';</script>";
		
		}
			
			
	}
 ?>

 

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!---scripts-->	
    <script src="common-js/jquery-3.2.1.min.js"></script>
	<script src="common-js/oh-autoval-script.js"></script>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="common-css/bootstrap.css" rel="stylesheet">
	<link href="common-css/fluidbox.min.css" rel="stylesheet">
	<link href="common-css/font-icon.css" rel="stylesheet">
	<link href="common-css/main.css" rel="stylesheet">
	<link href="common-css/responsive.css" rel="stylesheet">
	<link href="css/user_signup.css" rel="stylesheet"> 
	<link href="common-css/autoval-style.css" rel="stylesheet">
</head>
<body>
	<header>
		<div class="container">
			<a class="logo" href="#"><img src="images/logo-white.png" alt="Logo"></a>
			<div class="menu-nav-icon" data-nav-menu="#main-menu"><i class="icon icon-bars"></i></div>
			<ul class="main-menu visible-on-click" id="main-menu">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php" >GALLERY</a></li>
				<li><a href="register.php" >SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul><!-- main-menu -->
		</div><!-- container -->
	</header>
	<div class="m-slider">
<style>
.tbl-row-main{
	padding:20px;padding-left:30px;
}
#button{
	margin:10px;
	padding:3px;
	width:250px;
}
</style>
	<div class="form1">
		<form name="myform" id="registration"  class="oh-autoval-form" method="post" action="#">

			<center>
			<h2>Register Here</h2>
			<table style="padding:20px;padding-left:30px;">
			<tr class="tbl-row-main"><td><input type="text" class="av-name" av-message="Invalid Name" name="name" id="button" placeholder="Name" required="" autocomplete="off"></td></tr>
			<tr class="tbl-row-main"><td><input type="text" class="av-name" av-message="Invalid Place" name="place"  id="button" placeholder="Place" required="" autocomplete="off"></td></tr>
			<tr class="tbl-row-main"><td><input type="text" class="av-mobile" av-message="Invalid Mobile Number" name="mobile"  id="button" placeholder="Mobile Number" required=""  autocomplete="off"></td></tr>
			<tr class="tbl-row-main"><td><input type="email" class="av-email" av-message="Invalid email address" name="email"  id="button" placeholder="E-mail" required=""  autocomplete="off"></td></tr>
			<tr class="tbl-row-main"><td><input type="password" class="av-password" av-message="Invalid Password" name="password" id="button" placeholder="Password" required="" autocomplete="off"></td></tr>
			<tr class="tbl-row-main"><td><input type="password" class="av-password" av-message="Invalid Confirm Password" name="cpassword" id="button" placeholder="Confirm Password" required="" autocomplete="off" ></td></tr>
			</table></center>
			<input type="submit" value="Register" id="submit" name="submit">
	
		</form>
	</div>
	</div>

	<!-- SCIPTS -->
	<script src="common-js/jquery-3.1.1.min.js"></script>
	<script src="common-js/tether.min.js"></script>
	<script src="common-js/bootstrap.js"></script>
	<script src="common-js/jquery.countdown.min.js"></script>
	<script src="common-js/jquery.fluidbox.min.js"></script>
	<script src="common-js/scripts.js"></script>
	
</body>
</html>