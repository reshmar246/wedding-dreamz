<?php
include_once 'conn.php';
session_start();
$q1=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}


if(isset($_POST['submit']))
{
	//$amt=$_POST['total_amount'];
	$card_no=$_POST['card_no'];
	$holdername=$_POST['holdername'];
	$month=$_POST['month'];
	$year=$_POST['year'];
	$cvv=$_POST['cvv'];
	$amount=$_POST['amount'];
	
	$a=mysqli_query($con,"SELECT  * FROM tbl_paycard_details WHERE  `pay_card_no`=$card_no AND `pay_expiry_month`=$month AND `pay_expiry_year`=$year AND `pay_card_holder_name`=$holdername AND `pay_card_cvv`=$cvv");
   		
	if($a=NULL){
		echo "<script>alert('Wrong Card Details..!');window.location.href='cart.php';</script>";
	}
	else
	{
	   $b=mysqli_query($con,"SELECT * FROM tbl_paycard_details WHERE  `pay_card_no`=$card_no ");
       
	   while($row10=mysqli_fetch_array($b))
	   {
	
		$balance = $row10['pay_balance'];
		$paycard_detail_id = $row10['paycard_detail_id'];
			
			if($balance<$amount)
			{
				echo "<script>alert('Insufficient balance in Account..!');window.location.href='cart.php';</script>";
	        }
			else
			{
				echo $res=mysqli_query($con,"UPDATE `tbl_add_cart` SET order_status=1,cart_status=0 WHERE cart_status=1 and login_id=$user_id");
				$cur_balance=$balance-$amount;
				
				$rest=mysqli_query($con,"UPDATE `tbl_paycard_details` SET pay_balance=$cur_balance WHERE paycard_detail_id=$paycard_detail_id ");
				
				$b=mysqli_query($con,"SELECT * FROM tbl_paycard_details WHERE  paycard_detail_id=3 ");
                 while($row102=mysqli_fetch_array($b))
				{
					$bal = $row102['pay_balance'];
					$pay_id = $row102['paycard_detail_id'];
					$c_balance=$bal+$amount;
					$reslt=mysqli_query($con,"UPDATE `tbl_paycard_details` SET pay_balance=$c_balance WHERE paycard_detail_id=$pay_id ");
				}
				
				$date = date('Y-m-d');
			    $result10=mysqli_query($con,"INSERT INTO `tbl_payment`(`paycard_detail_id`,`paid_date`,`paid_amount`, `login_id`, `pay_status`) VALUES ('$pay_id','$date ','$amount','$user_id','1')");
				
				echo "<script>alert('Payment Done Successfully..!');window.location.href='cart.php';</script>";
	
			}
		}
	}
	
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!---scripts-->	
    <script src="../common-js/jquery-3.2.1.min.js"></script>
	<script src="../common-js/oh-autoval-script.js"></script>
	<script src="../common-js/modernizr-2.8.3.min.js"></script>
	<!-- Stylesheets -->
	<link href="../common-css/bootstrap.css" rel="stylesheet">
	<link href="../common-css/fluidbox.min.css" rel="stylesheet">
	<link href="../common-css/font-icon.css" rel="stylesheet">
	<link href="../common-css/styles.css" rel="stylesheet">
	<link href="../common-css/responsive.css" rel="stylesheet">
    
</head>
<body style="background: #dde0ec;">

	<div class="pay-header">
		<div style="margin-left:100px;">
		<a href="#" class="logoa" style="width: 200px;height:50px;"><img src="../images/hdfc.jpg" style="position:relative;width: 200px;height:50px;"></a>
		<a href="#" class="logoa" style="width: 200px;height:50px;"><img src="../images/sbi.jpg" style="position:relative;width: 200px;height:50px;"></a>
		<a href="#" class="logoa" style="width: 200px;height:50px;"><img src="../images/pnb.jpg" style="position:relative;width: 200px;height:50px;"></a>
		<a href="#" class="logoa" style="width: 200px;height:50px;"><img src="../images/fede.jpg" style="position:relative;width: 200px;height:50px;"></a>
	</div>
	</div>
	
	
<style>
.pay-header{
	float:left;
	background-color:#fff;
	padding:10px;
	margin-top:0px;
	margin-bottom:20px;
	height:70px;
	width:100%;
	box-shadow: 0 0 5px 2px #cfd2dd;
}
.logoa{
	color: #333;
	outline: 0 none;
    text-decoration: none;
	margin-left:70px;
}	
.pay-container{
	box-shadow: 0 0 5px 2px #cfd2dd;
	background-color:#fff;
	margin-top:10px;
	margin-left:100px;
	margin-bottom:40px;
	margin-right:100px;
	float:left;
	height:100%;	
}
.billing-inf{
	background: #004a8f;
    color: #fff;
	padding:10px;
	padding-top:30px;
	float:left;
	width:30%;
	position:relative;
	height:100%;
}
.content{
	background-color:#fff;
	padding:10px;
	float:left;
	width:60%;
	position:relative;
}
.icona{
	width:20px;
	height:20px;
	border:none;
	background:none;
	float:left;
	margin:10px;
}
.heading{
	float:left;
	border-bottom: 1px #fff solid;
	padding-top:20px;
	padding-bottom:15px;
	padding:5px;
	width:100%;
}
.headings{
	float:left;
	border-bottom: 1px #fff solid;
	padding-top:15px;
	padding:5px;
	width:100%;
}
</style>

<div class="pay-container">
			<?php
				$query=mysqli_query($con,"SELECT * FROM `tbl_registration` where login_id=$user_id")or die(mysqli_error($con));
				while ($row=mysqli_fetch_array($query)) {
					$amount=$_GET["amount"];
			?>
	<div class="billing-inf">
							
               <center><h4 class="hideInMobile" style="font-weight:400;">Billing Information</h4></center>
			   <br><br>
               <div class="spacer20 hideInMobile"></div>
               <div class="heading">
                  
				  <img src="../images/amount.png" class="icona">
				  <div>
                  <p style="float:left;font-size:21px;color:#fff;padding-left:10px;">Amount</p><br>
                  <h5 style="font-size:32px;color:#fff;position:relative;margin-top:10px;padding-left:12px;">&nbsp;Rs.  <span id="totalAmount"  class="finalAmuntValue"><?php echo $amount;?> </span> </h5>
                  
				  </div>
                </div>
               <div class="heading">
                  <div>
                  <p style="float:left;font-size:18px;color:#fff;padding-left:20px;padding-top:20px;">User</p></div><br>
                  <p class="orderNo" title="10159_5cac21031d200" style="font-size: 25px;color:#fff;padding-top:20px;text-transform: uppercase;padding-left:22px;position:relative;margin-top:10px;"><?php echo $row['reg_name']?> </p>
               </div>
			   <div></div>
	</div>
	
<style>
.tr-pay{
	padding-top:10px;
	border:none;
}
.td1{
	font-size:18px;
	width:200px;
}
.td2{
	font-size:16px;
}
#form-control {
    width: 320px;
    height: 35px;
    box-shadow: none;
	border-radius:2px;
    border: 1px solid #d2d2e4;
}
#date {
    width: 100px;
    height: 35px;
    box-shadow: none;
	border-radius:2px;
    border: 1px solid #d2d2e4;
}
</style>		
		<!-- CONTENT -->
	<div class="content">
        <center>
		<div class="container" style="padding-top:40px;padding-left:30px;">
		<div class="row" >
			
			<div class="col-sm-6">
				<div class="popform" align="center">
					<form   name="myform" id="payment"  class="oh-autoval-form" method="post"  style="height:100%;">
						
						<table style="width:600px;position:relative;height:310px;margin-left:20px;">
							<tr class="tr-pay">
								<td class="td1">Payment Type</td>
								<td class="td2"><select   name="payment_type"  id="form-control">
								<option value="debit card" id="debit">Debit Card</option>
								</select></td>
							</tr>
							<tr class="tr-pay">
								<td class="td1">Card Number </td>
								<td class="td2"><input type="text" class="av-number av-required" av-message="Enter a valid Number"   name="card_no" id="form-control" placeholder="Enter Card Number"  required=""></td>
							</tr>
							<tr class="tr-pay">
								<td class="td1">Expiry Date</td>
								<td class="td2"><select name="month" class="av-required" av-message="Enter Month"  id="date">
								<option selected disabled>MM</option>
								<?php
									for($i=1;$i<=12;$i++){
								?>
								<option value="<?php echo $i;?>"><?php echo $i;?></option>
								<?php
									}
								?>
							</select>
							<select name="year" class="av-required" av-message="Enter Year" id="date">
								<option selected disabled >YYYY</option>
								<?php
									for($i=2019;$i<=2100;$i++){
								?>
								<option value="<?php echo $i;?>"><?php echo $i;?></option>
								<?php
										}
								?>
							</select></td>
							</tr>
							<tr class="tr-pay">
								<td class="td1">CVV</td>
								<td class="td2"><input    type="text"  class="av-number av-required" av-message="Enter a valid CVV" name="cvv" id="form-control" placeholder="xxx"  required=""></td>
							</tr>
							<tr class="tr-pay">
								<td class="td1">Card Holder Name</td>
								<td class="td2"><input    type="text" class="av-name av-required" av-message="Enter a valid Name" name="holdername" id="form-control" placeholder="Card Holder Name"  required=""></td>
							</tr>
							
						</table>
						<input type="hidden" name="amount" value="<?php echo $amount;?>">
						<div style="padding:5px;margin:15px;margin-left:25px;">
							<input id="submit" type="submit" class="btn btn-default" style="background-color:#3498DB;color:white;border-radius: 5px;" name="submit" value="Pay Now">
						</div>
						
					</form>
					<div>
					<a href="cart.php" style="color:#004a8f;font-size:15px;">or Go Back </a>
					</div>
				</div>
			</div><!-- col -->
			<!-- widget-text -->
			<!-- widget-slider -->
		</div>
		</div><!-- row -->
	</div><!-- container -->
	
        <?php
				}
			?>
	</div>
	


	<!-- SCIPTS -->
	<script src="../common-js/jquery-3.1.1.min.js"></script>
	<script src="../common-js/tether.min.js"></script>
	<script src="../common-js/bootstrap.js"></script>
	<script src="../common-js/jquery.countdown.min.js"></script>
	<script src="../common-js/jquery.fluidbox.min.js"></script>
	<script src="../common-js/scripts.js"></script>
	<script>
					$(document).ready(function() {
					});
					$("#name").focusout(function(){
						if($("#name").val() == ""){
							$("#namelabel").css('display', 'block');
							$('#submit').attr('disabled', 'disabled');
						}
						else{
							$("#namelabel").css('display', 'none');
							$('#submit').removeAttr('disabled');
						}
					});
					$("#email").focusout(function(){
						if($("#email").val() == ""){
							$("#emaillabel").css('display', 'block');
							$('#submit').attr('disabled', 'disabled');
						}
						else{
							$("#emaillabel").css('display', 'none');
							$('#submit').removeAttr('disabled');
						}
					});
					$("#number").focusout(function(){
						if($("#number").val() == ""){
							$("#phonelabel").css('display', 'block');
							$('#submit').attr('disabled', 'disabled');
						}
						else{
							$("#phonelabel").css('display', 'none');
							$('#submit').removeAttr('disabled');
						}
					});
					$("#addresslabel").focusout(function(){
						if($("#address").val() == ""){
							$("#addresslabel").css('display', 'block');
							$('#submit').attr('disabled', 'disabled');
						}
						else{
							$("#addresslabel").css('display', 'none');
							$('#submit').removeAttr('disabled');
						}
					});
					$("#message").focusout(function(){
						if($("#message").val() == ""){
							$("#messagelabel").css('display', 'block');
							$('#submit').attr('disabled', 'disabled');
						}
						else{
							$("#messagelabel").css('display', 'none');
							$('#submit').removeAttr('disabled');
						}
					});
		</script>
</body>
</html>