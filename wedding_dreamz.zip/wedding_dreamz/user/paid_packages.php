<?php
include 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];	

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}

if(isset($_POST['btn_remove_paid_food'])){
	$item_id=$_POST['cart_item'];
	$cart_id=$_POST['item_cart'];
	mysqli_query($con, "DELETE FROM `tbl_add_cart` WHERE `item_id`='$item_id' and `cart_id`='$cart_id' and `package_id`='1'");
	echo "<script>alert('Item has been successfully removed..!');</script>";
}
if(isset($_POST['btn_remove_paid_hall'])){
	$item_id=$_POST['cart_item'];
	$cart_id=$_POST['item_cart'];
	 mysqli_query($con, "DELETE FROM `tbl_add_cart` WHERE `item_id`='$item_id' and `cart_id`='$cart_id' and `package_id`='2'");
	echo "<script>alert('Item has been successfully removed..!');</script>";
}
if(isset($_POST['btn_remove_paid_studio'])){
	$item_id=$_POST['cart_item'];
	$cart_id=$_POST['item_cart'];
	mysqli_query($con, "DELETE FROM `tbl_add_cart` WHERE `item_id`='$item_id' and `cart_id`='$cart_id' and `package_id`='3'");
	echo "<script>alert('Item has been successfully removed..!');</script>";
}
if(isset($_POST['btn_remove_paid_dress'])){
	$item_id=$_POST['cart_item'];
	$cart_id=$_POST['item_cart'];
	mysqli_query($con, "DELETE FROM `tbl_add_cart` WHERE `item_id`='$item_id' and `cart_id`='$cart_id' and `package_id`='4'");
	echo "<script>alert('Item has been successfully removed..!');</script>";
}
?>


<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="../common-css/bootstrap.css" rel="stylesheet">
	<link href="../common-css/fluidbox.min.css" rel="stylesheet">
	<link href="../common-css/font-icon.css" rel="stylesheet">
	<link href="../common-css/styles.css" rel="stylesheet">
	<link href="../common-css/responsive.css" rel="stylesheet">
    <link href="../common-css/oautoval-style.css" rel="stylesheet">
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!---scripts-->	
    <script src="../common-js/jquery-3.2.1.min.js"></script>
	<script src="../common-js/oh-autoval-script.js"></script>
	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <link href="../common-css/oautoval-style.css" rel="stylesheet">
	<link href="../css/add_item.css" rel="stylesheet">
		
	<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="css/main.css">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
    <!-- calendar CSS
		============================================ -->
    <link rel="stylesheet" href="css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.print.min.css">
    <!-- x-editor CSS
		============================================ -->
    <link rel="stylesheet" href="css/editor/select2.css">
    <link rel="stylesheet" href="css/editor/datetimepicker.css">
    <link rel="stylesheet" href="css/editor/bootstrap-editable.css">
    <link rel="stylesheet" href="css/editor/x-editor-style.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="css/data-table/bootstrap-editable.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="modernizr-2.8.3.min.js"></script>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
		<title>Wedding Dreamz</title>
</head>
<body>
	
	
<style>
.main-menu li a:hover{
	border:1px solid black;
	color:black;
	transition:0.6s ease;
}
.div-signout{
    background-color: #b4245d;
	padding:5px;
	padding-left:7px;
	box-shadow: 0 1px 3px 0 rgba(0,0,0,.2);
    width: 100px;
	float:right;
	position:relative;
	color:#fff;
}
.div-signout:hover{
	background-color: #DC143C;
	transition:0.6s ease;
}
.div-main-signout{
	padding-top:26px;
	padding-right:30px;
}
.main-menu{
	padding-right:90px;
}
.user-avatar-md {
    height: 35px;
    width: 35px;
}
.rounded-circle {
    border-radius: 50%!important;
	background:transparent;
    vertical-align: middle;
    border-style: none;
}

.navbar-nav .dropdown-menu {
    position: static;
    float: none;
}

.dropdown-menu {
    background: #fff;
    font-size: 14px;
    color: #3d405c;
    border: 1px solid #e6e6f2;
}
.nav-user-dropdown {
}
.nav-user-dropdown {
    padding: 0px;
    min-width: 230px;
    margin: 0px;
}
.notification-dropdown, .connection-dropdown, .nav-user-dropdown {
    padding: 0px;
    margin: 0px;
}
.dropdown-menu-right {
    right: 0;
    left: auto;
}
.dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 1000;
    display: none;
    float: left;
    min-width: 10rem;
    padding: .5rem 0;
    margin: .125rem 0 0;
    font-size: 1rem;
    color: #212529;
    text-align: left;
    list-style: none;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid rgba(0,0,0,.15);
    border-radius: .25rem;
}
.nav-user-info {
    background-color: #5969ff;
    line-height: 1.4;
    padding: 12px;
    color: #fff;
    font-size: 13px;
    border-radius: 2px 2px 0 0;
}
.text-white {
    color: #fff!important;
}
.mb-0, .my-0 {
    margin-bottom: 0!important;
}
.nav-user-info .status {
    float: left;
    top: 7px;
    left: 0px;
}
.ml-2, .mx-2 {
    margin-left: .5rem!important;
}
.nav-user-dropdown .dropdown-item {
    display: block;
    width: 100%;
    padding: 12px 22px 15px;
    clear: both;
    font-weight: 400;
    color: #686972;
    text-align: inherit;
    white-space: nowrap;
    background-color: transparent;
    border: 0;
    font-size: 13px;
    line-height: 0.4;
}
 .fas {
    font-family: 'Font Awesome 5 Free';
    font-weight: 900;
}
.fa, .fas, .far, .fal, .fab {
    -moz-osx-font-smoothing: grayscale;
    -webkit-font-smoothing: antialiased;
    display: inline-block;
    font-style: normal;
    font-variant: normal;
    text-rendering: auto;
    line-height: 1;
}
.mr-2, .mx-2 {
    margin-right: .5rem!important;
}
.navbar-right-top .nav-item:last-child {
    border: none;
}

.navbar-right-top .nav-item {
    border-right: 1px solid #e6e6f2;
}
.nav-user {
}
.dropdown, .dropleft, .dropright, .dropup {
    position: relative;
}
.nav-link:hover{
	
background-color: #e72e77;
}
</style>
	
	  <header>
	  <div style="float:left;margin-left:30px;margin-right:5px;">
		<a href="#" style="margin-right:15px;padding:10px;font-size: 23px;text-transform: uppercase;text-decoration:none;font-weight: 600;color: #fff;">Wedding Dreamz</a>
	  </div>
		
		<div class="container" style="position:relative;margin-right:15px;">
			<div class="menu-nav-icon" data-nav-menu="#main-menu"><i class="icon icon-bars"></i></div>
			<ul class="main-menu visible-on-click" id="main-menu">
			<li><a href="user_home.php" style="color:white;text-decoration:none;font-weight:500;    font-family: 'Bitter', serif;">HOME</a></li>
			<li><a href="user_packages.php" style="color:white;text-decoration:none;font-weight:500;    font-family: 'Bitter', serif;">PACKAGES</a></li>
			<li><a href="cart.php" style="color:white;text-decoration:none;font-weight:500;    font-family: 'Bitter', serif;">CART</a></li>
			<li><a href="paid_packages.php" style="color:white;text-decoration:none;font-weight:500;    font-family: 'Bitter', serif;">PAID</a></li>
		<?php
				$query100=mysqli_query($con,"SELECT * FROM `tbl_registration` where login_id=$user_id")or die(mysqli_error($con));
				while ($row100=mysqli_fetch_array($query100)) {
			?>
			
			<li id="dropdown-user" class="dropdown" >
                <a href="#" data-toggle="dropdown" class="dropdown-toggle text-right" >
                    <span class="ic-user pull-right">
                        <img class="img-circle img-user media-object" src="../images/user2.jpg" >
                                                         
                    </span>
                </a>
                <div class="dropdown-menu dropdown-menu-md dropdown-menu-right panel-default" style="opacity: 1;margin-top:1px;">
					<div class="nav-user-info">
                       <h5 class="mb-0 text-white nav-user-name" style="text-transform: uppercase;margin-left:10px;"><?php echo $row100['reg_name']?> </h5>
                        <span class="status"></span><span class="ml-2">Available</span>
                    </div>                
                <ul class="head-list">
                    <li>
                        <a href="user_profile.php"><div style="float:left;margin-right:10px;"><img src="../images/profile.png" style="width:20px;height:20px;background:transparent;border:none;padding:4px;"></div> Profile</a>
                    </li>
                   <li>
                        <a href="change_password.php"><div style="float:left;margin-right:10px;"><img src="../images/key1.png" style="width:20px;height:20px;background:transparent;border:none;padding:4px;"></div>Change Password</a>
                    </li>
                     <li>
                        <a href="logout.php"><div style="float:left;margin-right:10px;"><img src="../images/logout.png" style="width:20px;height:20px;background:transparent;border:none;padding:4px;"></div> Logout</a>
                    </li>   
                </ul>
                               
                
                </div>
            </li>
					
		<?php
				}
		?>
        
			
            </ul>
            </div>
				
	</header>
	
	<div class="header-main-slider" style="background-color: #e72e77;width: 100%;height:75px;">
		<!-- <div class="div-main-signout">
		<div class="div-signout">
			
		</div>
	</div>-->
			
	</div><!-- main-slider -->
	
<style>
#dropdown-user {
    float: right;
	background-color: #e72e77;
}
.dropdown-toggle{
	background-color: #e72e77;
}
@media (max-width: 760px)
#dropdown-user{
    position: static;
}
#dropdown-user>a, #dropdown-user>a:focus {
    background-color: #e72e77 !important;
    color: #d9d9d9;
}
#dropdown-user>a, #dropdown-user>a:focus {
    background-color: ##e72e77!important;
    color: #677882;
}
 .open>a, .open>a:focus, .open>a:hover {
    background-color: #eee;
    border-color: #337ab7;
}
.nav-user-info {
    background-color: 	 #e72e77;
    line-height: 1.4;
    padding: 5px;
	padding-left:10px;
    color: #fff;
	height:60px;
    font-size: 13px;
    border-radius: 2px 2px 0 0;
}
.text-white {
    color: #fff!important;
}
.mb-0, .my-0 {
    margin-bottom: 0!important;
}
.nav-user-info .status {
    float: left;
    top: 5px;
    left: 0px;
}

#dropdown-user>a {
    display: table-cell;
    padding: 2px;
    height: 55px;
    color: #8f9ea6;
    transition: all .4s;
}
#dropdown-user .ic-user {
    font-size: 1.5em;
    height: 5px !important;
    line-height: 59px;
}
#dropdown-user .ic-user {
    font-size: 1.5em;
    height: 55px;
    line-height: 59px;
}
.pull-right {
    float: right;
}
.pull-right {
    float: right!important;
}
.img-user {
    width: 32px;
    height: 32px;
    box-shadow: 0 0 0 2px rgba(0,0,0,0);
	padding-top:0px;
}

.media-object {
    display: block;
}
.img-circle {
    border-radius: 50%;
}
@media (max-width: 760px)
 .dropdown-menu {
    width: auto;
    left: 10px;
    right: 10px;
}
.open>.dropdown-menu {
    display: block;
}
.dropdown-menu {
    z-index: 10000 !important;
}
.dropdown-menu-md {
    min-width: 200px;
}
.dropdown-menu-right {
    left: auto;
    right: 0;
}
.dropdown-menu {
    font-size: 14px;
    box-shadow: 0 3px 7px rgba(0,0,0,.3);
    margin: 0;
    padding: 0;
    border: 0;
}
.dropdown-menu :hover{
	border:none;
}
.head-list {
    list-style: none;
    padding: 0;

    margin: 0;
}
.dropdown-menu li:not(.active) a:not(:hover) {
    color: #4d627b;
}
 .head-list li a {
    display: block;
	border:none;
	width:200px;
	position:relative;
    padding: 12px 15px;
    transition: background .3s;
}
 .head-list li a:hover {
    display: block;
	border:none;
	width:200px;
	background-color: #FFFAFA	;
	position:relative;
    padding: 12px 15px;
    transition: background .3s;
}
.pad-all {
    padding: 15px;
}

.text-right {
    text-align: right;
}
.btn-purple{
    background-color:	#FFC0CB;
    border-color:	#FFC0CB !important;
    color: #fff;
}
.btn {
    cursor: pointer;
    background-color: 	#FFC0CB;
    color: inherit;
    padding: 6px 12px;
    border: 1px solid transparent;
    font-size: 13px;
    line-height: 1.475;
    vertical-align: middle;
    transition: all .25s;
}
.btn-purple :hover{
background-color: #FFC0CB;
}
</style>

<style>
body {
	font-family: Arial;
	color: #211a1a;
	font-size: 0.9em;
}
.cart-table{
	position:relative;
	padding:20px;
	padding-top:10px;
	margin:5px;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.1);
	transition: 0.5s;
	float:left;
	width:100%;
	height:170px;
}
.cart-desc-img{
	width:230px;
	height:150px;
	float:left;
}
.details{
	position:relative;
	margin-left:260px;
	margin-top:10px;
	width:300px;
	height:100%;
	font-size:17px;
}
</style>	
	<!-- CONTENT -->
<div class="content" style="padding:30px;">
		<div class="container">
			<div class="row">

			<div class="col-sm-12">
					<h3><center>PAID PACKAGES</center></h3>
				</div><!-- col -->
				
			</div><!-- row -->
		</div><!-- container --><br><br>
		<div class="container">
			<div class="row">
				<center><img class="cart-empty-img" src="../images/cart.png" style="margin-left:400px;"><br>
				<h5 style="margin-left:400px;">No Paid Packages</h5></center>
						
			<div class="cart-rows">
			
			
	<div class="pills-regular" style="width:100%">
                <ul class="nav nav-pills mb-1" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="home" aria-selected="true">Packages to be done</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="contact" aria-selected="false">Completed</a>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent" style="padding:0px;padding-bottom:0px;height:auto;width:100%;">
                    <div class="tab-pane show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                        

                <div class="card">
                    <h5 class="card-header" style="margin-top:0px;">Packages to be done</h5>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table style="font-size:15px;" class="table table-striped table-bordered first" id="table" data-toggle="table"  data-search="true" >
                              <thead>
                                    <tr>
										<th data-field="Item" data-editable="false">Item</th>
										<th data-field="Package" data-editable="false">Package</th>
										<th data-field="Employee" data-editable="false">Quantity</th>
                                        <th data-field="Wedding Date" data-editable="false">Wedding ID</th>
                                        <th data-field="Place" data-editable="false">Price</th>
                                    </tr>
                                </thead>
        
								<tbody>
								
		<?php
				//$total=0;$total1=0;$total2=0;$total3=0;$total4=0;
				$query=mysqli_query($con,"select * from tbl_add_cart where login_id=$user_id  and cart_status=0 ORDER BY item_id DESC");
				while ($row1=mysqli_fetch_array($query)) 
				{
				$package_id = $row1['package_id'];	
				$item_id = $row1['item_id'];	
				$cart_id = $row1['cart_id'];
				$wedding_id = $row1['wedding_id'];
				
				$querys=mysqli_query($con,"select * from tbl_userdetails where wedding_id=$wedding_id  and wedding_status=0");
				while ($rows1=mysqli_fetch_array($querys)) 
				{
				if($package_id=='1')
				{
					$query2=mysqli_query($con,"select DISTINCT `tbl_catering`.`food_name`,`tbl_image`.`image`,`tbl_catering`.`food_price` from `tbl_catering`,`tbl_image` where `tbl_catering`.`catering_id`=$item_id AND `tbl_image`.`item_img_id`= `catering_id` AND `tbl_image`.`package_id`=`tbl_catering`.`package_id` AND `tbl_image`.`image_status`=1");
					while($row10=mysqli_fetch_array($query2)){

		?>
								<tr>
										<td><?php echo $row10['food_name']?></td>
                                        <td>Food</td>
                                        <td><?php echo $row1['cart_quantity']?></td>
                                        <td><?php echo $rows1['wedding_user_id']?></td>
                                        <td><?php echo $row1['cart_price']?></td>
										
                                    </tr>
				<?php
					}
					}
					else if($package_id=='2'){
						$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_hall_decor`.stage_dec_name,`tbl_hall_decor`.stage_price  from tbl_hall_decor,tbl_image where `tbl_hall_decor`.`hall_id`=$item_id AND `tbl_image`.`item_img_id`= `hall_id` AND `tbl_image`.`package_id`=`tbl_hall_decor`.`package_id` AND `tbl_image`.`image_status`=1");
						while($row10=mysqli_fetch_array($query2)){
				?>
				
								<tr>
                                        <td><?php echo $row10['stage_dec_name']?></td>
                                        <td>Hall Decoration</td>
                                        <td><?php echo $row1['cart_quantity']?></td>
                                        <td><?php echo $rows1['wedding_user_id']?></td>
                                        <td><?php echo $row1['cart_price']?></td>
										
                                    </tr>
				<?php
					}
					}
					else if($package_id=='3'){
						$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_studio`.photo_package_name,`tbl_studio`.studio_price from tbl_studio,tbl_image where `tbl_studio`.`studio_id`=$item_id AND `tbl_image`.`item_img_id`= `studio_id` AND `tbl_image`.`package_id`=`tbl_studio`.`package_id` AND `tbl_image`.`image_status`=1");
						while($row10=mysqli_fetch_array($query2)){
				?>
				
								<tr>
                                        <td><?php echo $row10['photo_package_name']?></td>
                                        <td>Studio</td>
                                        <td><?php echo $row1['cart_quantity']?></td>
                                        <td><?php echo $rows1['wedding_user_id']?></td>
                                        <td><?php echo $row1['cart_price']?></td>
										
                                    </tr>
				
				<?php
					}
					}
					else if($package_id=='4'){
						$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_dress`.`dress_name`,`tbl_dress`.`dress_price` from tbl_dress,tbl_image where `tbl_dress`.`dress_id`=$item_id AND `tbl_image`.`item_img_id`= `dress_id` AND `tbl_image`.`package_id`=`tbl_dress`.`package_id` AND `tbl_image`.`image_status`=1");
						while($row10=mysqli_fetch_array($query2)){
				?>
				
								<tr>
                                        
										<td><?php echo $row10['dress_name']?></td>
                                        <td>Dress</td>
                                        <td><?php echo $row1['cart_quantity']?></td>
                                        <td><?php echo $rows1['wedding_user_id']?></td>
                                        <td><?php echo $row1['cart_price']?></td>
										
                                    </tr>
				<?php
					}
					}
				}}
				?>
								</tbody>
<style>
#icon-edit{
	color:black;
	padding:5px;
	display: inline-block;
	box-sizing: border-box;
	background-color: #D3D3D3;
	cursor: pointer; 
	border:20px;
}
#icon-edit:hover{
	background-color: #A9A9A9;
}
</style>
		</table>
        </div>
        </div>
		
        </div>
        
		</div>
		
                    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
<style>
#employee_name ,#package_name {
    width: 250px;
    height: 35px;
    box-shadow: none;
    border: 1px solid #d2d2e4;
}

button.pd-setting-ed {
    display: inline-block;
    margin-right: 5px;
}
.fa {
    display: inline-block;
    font: normal normal normal 14px/1 FontAwesome;
    font-size: inherit;
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
button.pd-setting-ed {
    padding: 5px 10px;
    font-size: 14px;
    border-radius: 3px;
    border: 1px solid rgba(0,0,0,.12);
    background: #f5f5f5;
}
table td {
    padding: 9px 7px;
    border-top: 1px solid #e9ecef;
}
.td-emp-img {
    width: 60px;
	height: 60px;;
}
</style>		
		<div class="card">
                    <h5 class="card-header" style="margin-top:0px;">Completed Works</h5>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table style="font-size:15px;" class="table table-striped table-bordered first" id="table" data-toggle="table"  data-search="true" >
                              <thead>
                                    <tr>
										<th data-field="Item" data-editable="false">Item</th>
										<th data-field="Package" data-editable="false">Package</th>
										<th data-field="Employee" data-editable="false">Quantity</th>
                                        <th data-field="Wedding Date" data-editable="false">Wedding ID</th>
                                        <th data-field="Place" data-editable="false">Price</th>
                                    </tr>
                                </thead>
        
								<tbody>
								
		<?php
				//$total=0;$total1=0;$total2=0;$total3=0;$total4=0;
				$query=mysqli_query($con,"select * from tbl_add_cart where login_id=$user_id  and cart_status=0 ORDER BY item_id DESC");
				while ($row1=mysqli_fetch_array($query)) 
				{
				$package_id = $row1['package_id'];	
				$item_id = $row1['item_id'];	
				$cart_id = $row1['cart_id'];
				$wedding_id = $row1['wedding_id'];
				
				$querys=mysqli_query($con,"select * from tbl_userdetails where wedding_id=$wedding_id  and wedding_status=1");
				while ($rows1=mysqli_fetch_array($querys)) 
				{
				if($package_id=='1')
				{
					$query2=mysqli_query($con,"select DISTINCT `tbl_catering`.`food_name`,`tbl_image`.`image`,`tbl_catering`.`food_price` from `tbl_catering`,`tbl_image` where `tbl_catering`.`catering_id`=$item_id AND `tbl_image`.`item_img_id`= `catering_id` AND `tbl_image`.`package_id`=`tbl_catering`.`package_id` AND `tbl_image`.`image_status`=1");
					while($row10=mysqli_fetch_array($query2)){

		?>
								<tr>
										<td><?php echo $row10['food_name']?></td>
                                        <td>Food</td>
                                        <td><?php echo $row1['cart_quantity']?></td>
                                        <td><?php echo $rows1['wedding_user_id']?></td>
                                        <td><?php echo $row1['cart_price']?></td>
                                    </tr>
				<?php
					}
					}
					else if($package_id=='2'){
						$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_hall_decor`.stage_dec_name,`tbl_hall_decor`.stage_price  from tbl_hall_decor,tbl_image where `tbl_hall_decor`.`hall_id`=$item_id AND `tbl_image`.`item_img_id`= `hall_id` AND `tbl_image`.`package_id`=`tbl_hall_decor`.`package_id` AND `tbl_image`.`image_status`=1");
						while($row10=mysqli_fetch_array($query2)){
				?>
				
								<tr>
                                        <td><?php echo $row10['stage_dec_name']?></td>
                                        <td>Hall Decoration</td>
                                        <td><?php echo $row1['cart_quantity']?></td>
                                        <td><?php echo $rows1['wedding_user_id']?></td>
                                        <td><?php echo $row1['cart_price']?></td>
                                    </tr>
				<?php
					}
					}
					else if($package_id=='3'){
						$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_studio`.photo_package_name,`tbl_studio`.studio_price from tbl_studio,tbl_image where `tbl_studio`.`studio_id`=$item_id AND `tbl_image`.`item_img_id`= `studio_id` AND `tbl_image`.`package_id`=`tbl_studio`.`package_id` AND `tbl_image`.`image_status`=1");
						while($row10=mysqli_fetch_array($query2)){
				?>
				
								<tr>
                                        <td><?php echo $row10['photo_package_name']?></td>
                                        <td>Studio</td>
                                        <td><?php echo $row1['cart_quantity']?></td>
                                        <td><?php echo $rows1['wedding_user_id']?></td>
                                        <td><?php echo $row1['cart_price']?></td>
                                    </tr>
				
				<?php
					}
					}
					else if($package_id=='4'){
						$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_dress`.`dress_name`,`tbl_dress`.`dress_price` from tbl_dress,tbl_image where `tbl_dress`.`dress_id`=$item_id AND `tbl_image`.`item_img_id`= `dress_id` AND `tbl_image`.`package_id`=`tbl_dress`.`package_id` AND `tbl_image`.`image_status`=1");
						while($row10=mysqli_fetch_array($query2)){
				?>
				
								<tr>
                                        
										<td><?php echo $row10['dress_name']?></td>
                                        <td>Dress</td>
                                        <td><?php echo $row1['cart_quantity']?></td>
                                        <td><?php echo $rows1['wedding_user_id']?></td>
                                        <td><?php echo $row1['cart_price']?></td>
                                    </tr>
				<?php
					}
					}
				}}
				?>
								</tbody>
<style>
#icon-edit{
	color:black;
	padding:5px;
	display: inline-block;
	box-sizing: border-box;
	background-color: #D3D3D3;
	cursor: pointer; 
	border:20px;
}
#icon-edit:hover{
	background-color: #A9A9A9;
}
</style>
		</table>
        </div>
	
            
        </div>
        </div>
        
	
				</div>
                </div>
              </div>
			 
			
<style>
body {
	font-family: Arial;
	color: #211a1a;
	font-size: 0.9em;
}
.cart-table{
	position:relative;
	padding:20px;
	padding-top:10px;
	margin:5px;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.3);
	transition: 0.5s;
	float:left;
	width:100%;
	height:180px;
}
.cart-desc-img{
	width:230px;
	height:160px;
	float:left;
}
.details{
	position:relative;
	margin-left:260px;
	width:200px;
	height:100px;
	font-size:17px;
}
.cart-rows{
	position:absolute;
	padding:20px;
	padding-top:10px;
	margin:5px;
	background: #fff;
	width:100%;
}
.cart-buttons-remove{
	width:150px;
	height:20px;
	padding:5px;
}
.buttons{
	position:relative;
	padding-top:10px;
	padding-left:280px;
	width:400px;
	height:30px;
}
.btn-primary {
	background: #108FB8;
	color: #fff;
	border: 1px solid #108FB8;
}
.btn-primary:hover {
	background: #277088;
	color: #fff;
	border: 1px solid #277088;
}
.btn {
	margin:10px;
	font-family: "Work Sans", Arial, sans-serif;
	font-size: 15px;
	font-weight: 400;
	border-radius: 10px;
	transition: 0.2s;
	padding: 8px 20px;
}
.btnremove{
	background: #D7DBDD;
	color: black;
	border: 1px solid #D7DBDD;
	font-size: 15px;
	font-weight: 500;
	border-radius: 10px;
	transition: 0.2s;
	padding: 6px 16px;
	margin:1px;
}
.btnremove:hover{
	background: grey;
	color: black;
	border: 1px solid grey;
}
.cart-empty{
	width: 900px;
	background-color: #fff;
    border-radius: 2px;
    box-shadow: 0 1px 2px 0 rgba(0,0,0,.2);
	float:left;margin-left:35px;margin-right:20px;margin-bottom:60px;
}
.cart-empty-img{
	width: 170px;
	height:130px;
	padding-top:30px;
	margin:10px;
	position:relative;
}
.cart-det{
	width: 300px!important;
	display: inline-block;
    vertical-align: top;
    
    position: relative;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.3);
}
</style>		
			
		</div>
		</div>
	</div>
	</div><!-- CONTENT -->
	
	<!-- SCIPTS -->
    <!-- jquery
		============================================ -->
    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <!-- data table JS
		============================================ -->
    <script src="js/data-table/bootstrap-table.js"></script>
    <script src="js/data-table/tableExport.js"></script>
    <script src="js/data-table/data-table-active.js"></script>
    <script src="js/data-table/bootstrap-table-editable.js"></script>
    <script src="js/data-table/bootstrap-editable.js"></script>
    <script src="js/data-table/bootstrap-table-resizable.js"></script>
    <script src="js/data-table/colResizable-1.5.source.js"></script>
    <script src="js/data-table/bootstrap-table-export.js"></script>
    <!--  editable JS
		============================================ -->
    <script src="js/editable/jquery.mockjax.js"></script>
    <script src="js/editable/mock-active.js"></script>
    <script src="js/editable/select2.js"></script>
    <script src="js/editable/moment.min.js"></script>
    <script src="js/editable/bootstrap-datetimepicker.js"></script>
    <script src="js/editable/bootstrap-editable.js"></script>
    <script src="js/editable/xediable-active.js"></script>
    <!-- Chart JS
		============================================ -->
    <script src="js/chart/jquery.peity.min.js"></script>
    <script src="js/peity/peity-active.js"></script>
    <!-- tab JS
		============================================ -->
    <script src="js/tab.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="js/main.js"></script>
	
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
	
	
	
	<script src="../common-js/jquery-3.1.1.min.js"></script>
	<script src="../common-js/tether.min.js"></script>
	<script src="../common-js/bootstrap.js"></script>
	<script src="../common-js/jquery.countdown.min.js"></script>
	<script src="../common-js/jquery.fluidbox.min.js"></script>
	<script src="../common-js/scripts.js"></script>
	
</body>
</html>