<?php
include 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}


if(isset($_POST['edit_profile_button'])) {
	$bride_name= $_POST['bride_name'];
	$groom_name= $_POST['groom_name'];
	$wed_date= $_POST['wed_date'];
	$bride_address = $_POST['bride_address'];
	$groom_address = $_POST['groom_address'];
	$religion_name = $_POST['religion_name'];
	
	$photo1=$_FILES['bride_photo']['name'];
	move_uploaded_file($_FILES['bride_photo']['tmp_name'],"upload/".$photo1);
	
	$photo2=$_FILES['groom_photo']['name'];
	move_uploaded_file($_FILES['groom_photo']['tmp_name'],"upload/".$photo2);
	
	$result = mysqli_query($con, "INSERT INTO tbl_userdetails(`bride_name`,`groom_name`,`wed_date`,`bride_address`,`groom_address`,`religion_name`,`bride_photo`,`groom_photo`,`login_id`) VALUES('$bride_name','$groom_name','$wed_date','$bride_address','$groom_address','$religion_name','$photo1','$photo2','$user_id')");
	header('Location: edit_profile.php');
		exit;
	if(mysqli_query($con,$result))
	{
		echo "<script>alert('Profile has created');</script>";
		
	}
		if(!$result){
		echo "<script>alert('Profile already exists..!');</script>";
	}
}
?>


<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
 
 <script type="text/javascript">
    function checkDate() {
        var dateString = document.getElementById('date').value;
        var myDate = new Date(dateString);
        var today = new Date();
        if ( myDate > today ) { 
            $('#date').after('<p>You cannot enter a date in the future!.</p>');
            return false;
        }
        return true;
    }
</script>	
    <script src="../common-js/jquery-3.2.1.min.js"></script>
	<script src="../common-js/oh-autoval-script.js"></script>
	<!-- Stylesheets -->
	<link href="../common-css/bootstrap.css" rel="stylesheet">
	<link href="../common-css/fluidbox.min.css" rel="stylesheet">
	<link href="../common-css/font-icon.css" rel="stylesheet">
	<link href="../common-css/styles.css" rel="stylesheet">
	<link href="../common-css/responsive.css" rel="stylesheet">
	<link href="../common-css/header_style.css" rel="stylesheet">
	<link href="../common-css/autoval-style.css" rel="stylesheet">
</head>
<body>
<style>
.tbl-row{
	padding:10px;
}
</style>	
    <?php include 'header.php'; ?>
	
	<div></div>
	<div class="div-main-slider" style="position:relative;">
	<div class="div-content" style="padding:30px;padding-top:35px;padding-left:70px;">
		 
		 
		 <div class="content-wrapper" style="background-image:url(../images/hd2.jpeg);">
		<?php
		include 'conn.php';
   
			$query=mysqli_query($con,"SELECT * FROM `tbl_login`,`tbl_registration` WHERE `tbl_login`.login_id=`tbl_registration`.login_id AND login_role=2 AND `tbl_login`.login_id=$user_id");
			while($row=mysqli_fetch_array($query))
			{
		?>
		
<style>
.btn-primary{
	margin-right:30px;
}
.btn-primary a{
    color: #fff;
    background-color: #5969ff;
    border-color: #5969ff;
	    font-size: 14px;
    padding: 9px 16px;
    border-radius: 2px;
}
.btn-primary:hover a{
    color: #fff;
    background-color: #6610f2;
    border-color:#6610f2;
}
</style>	


			<div style="float:right;" class="btn-primary">
				<a href="edit_profile.php?rid=<?php echo $row['reg_id'] ?>&lid=<?php echo $row['login_id'] ?>"><i class="fas fa-edit" data-original-title="edit"  id="icon-edit" ></i>&nbsp;Edit Profile</a>
			</div>
			
			<div class="main-prof">
			<div class="profile-main">
				<center><h3><u>PROFILE</u></h3><br>
				<div class="profile-img">
					<img src="../images/pers1.png" style="position:relative;width:60px;height:60px;">
				</div>
				
				<table>
					<tr>
						<td class="tbl-row-hd">Name</td>
						<td class="tbl-row-hd">:&nbsp; <?php echo $row['reg_name']?></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Place</td>
						<td class="tbl-row-hd">: &nbsp;<?php echo $row['reg_place']?></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Phone</td>
						<td class="tbl-row-hd">:&nbsp; <?php echo $row['reg_phone']?></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Email-id</td>
						<td class="tbl-row-hd">: &nbsp;<?php echo $row['username']?></td>
					</tr>
				</table>
			</center>	
			</div>
		</div>
		<?php
		}
		?>
		
	
        </div>
        <!-- content-wrapper ends -->
   
			
    
<style>
.profile-main{
	position:relative;
	padding:20px;
	margin:10px;
	padding-top:35px;
	margin-left:280px;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.1);
	transition: 0.5s;
	float:left;
	width:500px;
	height:500px;
	font-size:17px;
}

.main-prof{
	background-image:url(../images/hd2.jpeg);
	position:relative;
	width:100%;
}
.profile-img{
	float:left;
	margin-left:180px;
	width:100px;
	height:100px;
}
.tbl-row-hd{
	padding:5px;
}
</style> 



		</div>
	</div><!-- main-slider -->
	
	
	
	<!-- SCIPTS -->
	<script src="../common-js/jquery-3.1.1.min.js"></script>
	<script src="../common-js/tether.min.js"></script>
	<script src="../common-js/bootstrap.js"></script>
	<script src="../common-js/jquery.countdown.min.js"></script>
	<script src="../common-js/jquery.fluidbox.min.js"></script>
	<script src="../common-js/scripts.js"></script>
	
</body>
</html>