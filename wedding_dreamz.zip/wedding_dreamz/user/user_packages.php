<?php
include 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}

?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="../common-css/bootstrap.css" rel="stylesheet">
	<link href="../common-css/fluidbox.min.css" rel="stylesheet">
	<link href="../common-css/font-icon.css" rel="stylesheet">
	<link href="../common-css/styles.css" rel="stylesheet">
	<link href="../common-css/responsive.css" rel="stylesheet">
	<link href="../css/u_package.css" rel="stylesheet">

</head>
<body>

	<?php include 'header.php'; ?>
	
	<section class="section story-area center-text">
		<div class="container" style="margin-top:0px;margin-bottom:0px;">
			<div class="row">
				<div class="col-sm-1"></div>
				<div class="col-sm-10">
					
					<div class="heading" style="padding:10px;">
						<h3 class="title" style="font-family:  Times New Roman, serif;">PACKAGES</h3>
						<span class="heading-bottom"><i class="icon icon-star"></i></span>
					</div>

					<p class="desc margin-bottom"style="padding-bottom:0px;">Every bride and groom wants an incomparable wedding combined with fantasy 
					and style. We create stunning, one-of-a-kind events produced and styled to perfection. 
					From traditional to modern, elegant and relaxed, we focus on any event we plan.</p>
					
				</div><!-- col-sm-10 -->
			</div><!-- row -->
		</div><!-- container -->
	</section><!-- section -->
		
	<!--================Blog Category Area =================-->
        <section class="blog_categorie_area">
            <div class="container_pack">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="categories_post">
                            <img src="../images/decoration/dec2.jpg" alt="post">
                            <a href="hall-decor/hall_decoration-all-category.php">
							<div class="categories_details">
                                <div class="categories_text">
                                   <h4>Hall Decorations</h4>
                                    <div class="border_line"></div>
                                    <p>Be a part of wedding</p>
                                </div>
                            </div>
							</a>
                        </div>
                        
                    </div>
                    <div class="col-lg-4">
                        <div class="categories_post">
                            <img src="../images/studio/pic1.jpg" alt="post">
                                    <a href="studio/studio-all-category.php">
                            <div class="categories_details">
                                <div class="categories_text"><h4>Studio</h4>
                                    <div class="border_line"></div>
                                    <p>Enjoy happiness together</p>
                                </div>
                            </div>
							</a>
                        </div>
                    </div>
				</div>
			</div>
            <div class="container_pack">
                <div class="row">
					<div class="col-lg-4">
                        <div class="categories_post">
                            <img src="../images/dress/dress1.jpg" alt="post">
                                    <a href="dress/dress-all-category.php">
                            <div class="categories_details">
                                <div class="categories_text"><h4>Dress</h4>
                                    <div class="border_line"></div>
                                    <p>Enjoy happiness together</p>
                                </div>
                            </div>
							</a>
                        </div>
                    </div>
					<div class="col-lg-4">
						<div class="categories_post">
                            <img src="../images/food/cater2.jpg" alt="post">
                                    <a href="catering/catering-all-category.php">
                            <div class="categories_details">
                                <div class="categories_text"><h4>Catering</h4>
                                    <div class="border_line"></div>
                                    <p>Let the food be finished</p>
                                </div>
                            </div>
							</a>
                        </div>
                    </div>
					
                </div>
            </div>
        </section>
	
	<!--footer area-->
	<footer>
		<div class="container center-text">
			
			<div class="logo-wrapper">
				<a class="logo" href="#"><img src="../images/logo-black.png" alt="Logo Image"></a>
				<i class="icon icon-star" style="color:#E45F74;"></i>
			</div>
			<p><h4>Join us as we celebrate life and love.</h4></p>
			<i class="icon icon-heart" style="color:#E45F74;"></i>
			<br>
			<ul class="footer-links">
				<li><a href="user_home.php">HOME</a></li>
				<li><a href="user_packages.php">PACKAGES</a></li>
				<li><a href="cart.php">CART</a></li>
				<li><a href="paid_packages.php">PAID</a></li>
				<li><a href="logout.php" >SIGN OUT</a></li>
			</ul>
			<br>
			<ul class="social-icons">
				<li><a href="#"><i class="icon icon-twitter"></i></a></li>
				<li><a href="#"><i class="icon icon-instagram"></i></a></li>
				<li><a href="#"><i class="icon icon-pinterest"></i></a></li>
				<li><a href="#"><i class="icon icon-tripadvisor"></i></a></li>
			</ul><br>

		
		<div></div>
		</div><!-- container -->
	</footer>
	<!-- SCIPTS -->
	<script src="../common-js/jquery-3.1.1.min.js"></script>
	<script src="../common-js/tether.min.js"></script>
	<script src="../common-js/bootstrap.js"></script>
	<script src="../common-js/jquery.countdown.min.js"></script>
	<script src="../common-js/jquery.fluidbox.min.js"></script>
	<script src="../common-js/scripts.js"></script>
	
</body>
</html>