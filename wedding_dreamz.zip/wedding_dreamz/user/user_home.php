 <?php
include_once 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}

if(isset($_POST['edit_profile_button'])) {
	$bride_name= $_POST['bride_name'];
	$groom_name= $_POST['groom_name'];
	$wed_date= $_POST['wed_date'];
	$aname= $_POST['aname'];
	$aaddress= $_POST['aaddress'];
	$acity= $_POST['acity'];
	$pincode= $_POST['pincode'];
	$bride_address = $_POST['bride_address'];
	$groom_address = $_POST['groom_address'];
	$religion_name = $_POST['religion_name'];
	
	$photo1=$_FILES['bride_photo']['name'];
	move_uploaded_file($_FILES['bride_photo']['tmp_name'],"upload/".$photo1);
	
	$photo2=$_FILES['groom_photo']['name'];
	move_uploaded_file($_FILES['groom_photo']['tmp_name'],"upload/".$photo2);
	
	$result = mysqli_query($con, "INSERT INTO tbl_userdetails(`bride_name`,`groom_name`,`wed_date`,`wed_hall`,`wed_hall_address1`,`wed_hall_address2`,`wed_hall_pincode`,`bride_address`,`groom_address`,`religion_name`,`bride_photo`,`groom_photo`,`login_id`,`wedding_status`) VALUES('$bride_name','$groom_name','$wed_date','$aname','$aaddress','$acity','$pincode','$bride_address','$groom_address','$religion_name','$photo1','$photo2','$user_id','0')");
	
	$lid = mysqli_insert_id($con);
	$wid =$lid.$bride_name.$groom_name;
	$result22 = mysqli_query($con, "UPDATE `tbl_userdetails` SET `wedding_user_id`='$wid' WHERE `wedding_id`='$lid' AND `login_id`='$user_id' ");
	
    echo "<script>alert('Profile has created');window.location.href='user_home.php';</script>";
	
	if(mysqli_query($con,$result))
	{
		echo "<script>alert('Profile has created');</script>";
		
	}
		if(!$result){
		echo "<script>alert('Profile already exists..!');</script>";
	}
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="../common-css/bootstrap.css" rel="stylesheet">
	<link href="../common-css/fluidbox.min.css" rel="stylesheet">
	<link href="../common-css/font-icon.css" rel="stylesheet">
	<link href="../common-css/styles.css" rel="stylesheet">
	<link href="../common-css/responsive.css" rel="stylesheet">
	<link href="../common-css/oautoval-style.css" rel="stylesheet">
	
	
	 <script src="../common-js/jquery-3.2.1.min.js"></script>
	<script src="../common-js/oh-autoval-script.js"></script>
<script type="text/javascript">
    function checkDate() {
        var dateString = document.getElementById('date').value;
        var myDate = new Date(dateString);
        var today = new Date();
        if ( myDate < today ) { 
            $('#date').after('<p style="color:red;">Enter a valid date!.</p>');
            return false;
        }
        return true;
    }
</script>
<script type="text/javascript">
$(document).ready(function(){
	$("#add_profile").hide();
        $("#addp").click(function(e) {
            $("#add_profile").toggle("slow");
  return false;
            $("#addp").hide();
  });
});

</script>	
</head>
<body>
	
	<?php include 'header.php'; ?>
	
<style>
.btn-primarys{
	padding:13px;
	border-radius: 10px;
	background-color:#e72e77;
	color:#fff;
}
.btn-primarys:hover{
	padding:13px;
	border-radius: 10px;
	background-color:#B44668;
	color:#fff;
}
</style>	
		
	<div class="div-main-slider" style="position:relative;">
	<p style="padding:5px;text-align:center;color:red;">* Enter the Wedding Details to get your Wedding ID to purchase desired packages</p>
	<div class="div-content" style="padding:30px;">
	<div class="edit-box">
	
	
		<button type="button" id="addp" class="btn-primarys">Add Wedding Details</button>
		
			<form name="myform" id="add_profile" class="oh-autoval-form"  method="post" action="" enctype="multipart/form-data">
				<center><h3>Wedding Details</h3><br>
				<table>
				<tr>
					<td class="tbl-row">Bride Name</td>
					<td class="tbl-row">: &nbsp;<input type="text" class="av-name av-required" av-message="Invalid Name" name="bride_name" id="bride_name" placeholder="Bride Name"  style="width:250px;" required=""></td>
				</tr>
				<tr>
					<td class="tbl-row">Groom Name</td>
					<td class="tbl-row">: &nbsp;<input type="text" class="av-name av-required" av-message="Invalid Name" name="groom_name"  id="groom_name" placeholder="Groom Name"  style="width:250px;" required=""></td>
				</tr>
				<tr>
					<td class="tbl-row">Wedding Date</td>
					<td class="tbl-row">: &nbsp;<input type="date"  min="<?php echo date('Y-m-d'); ?>" class="button av-required"  av-message="Select Date" onclick="checkDOB()" name="wed_date"  onclick="checkDate()" id="date" placeholder="Wedding Date" style="padding:5px;width:250px;" required=""  ></td>
				</tr>
				<tr>
				<td class="tbl-row">Auditorium Name</td>
				<td class="tbl-row">:&nbsp; <input type="text" class="av-name av-required" av-message="Enter a valid Name" name="aname" id="button" placeholder="Company Name" style="width:250px;" required=""></td>
			</tr>
			<tr>
				<td class="tbl-row">Hall Address Line 1</td>
				<td class="tbl-row">:&nbsp; <input type="text" class="av-name av-required" av-message="Enter a valid Place" name="aaddress" id="button" placeholder="Address Line 1" style="width:250px;" required=""></td>
			</tr>
			<tr>
				<td class="tbl-row">Hall Address Line 2</td>
				<td class="tbl-row">:&nbsp; <input type="text" class="av-name av-required" av-message="Enter a valid Place" name="acity" id="button" placeholder="Address Line 2" style="width:250px;" required=""></td>
			</tr>
			<tr>
				<td class="tbl-row">Pincode</td>
				<td class="tbl-row">:&nbsp; <input type="text" class="av-pincode" av-message="Enter a valid Pincode" name="pincode" id="button" style="width:250px;" placeholder="Pincode" required=""></td>
			</tr>
				<tr>
					<td class="tbl-row">Bride Photo</td>
					<td class="tbl-row">: &nbsp;<input type="file" class="av-image av-required" av-message="Select valid Image(with .jpg,.jpeg,.png etc)" name="bride_photo"  id="bride_photo" style="width:250px;" required=""></td>
				</tr><tr>
					<td class="tbl-row">Groom Photo</td>
					<td class="tbl-row">: &nbsp;<input type="file" class="av-image av-required" av-message="Select valid Image(with .jpg,.jpeg,.png etc)" name="groom_photo"  id="groom_photo" style="width:250px;" required=""></td>
				</tr><tr>
					<td class="tbl-row">Bride Place</td>
					<td class="tbl-row">: &nbsp;<input type="text" class="av-name av-required" av-message="Invalid Place" name="bride_address"  id="bride_address" style="width:250px;" placeholder="Bride Place" required=""></td>
				</tr>
				<tr>
					<td class="tbl-row">Groom Place</td>
					<td class="tbl-row">: &nbsp;<input type="text" class="av-name av-required" av-message="Invalid Place" name="groom_address"  id="groom_address" style="width:250px;" placeholder="Groom Place" required=""></td>
				</tr>
				<tr>
					<td class="tbl-row">Religion</td>
					<td class="tbl-row">: &nbsp;<select   name="religion_name" id="religion_name" class="button av-required" placeholder="religion_name" style="padding:5px;width:250px;" required="">
					<option value="Hindu" name="religion_name" id="religion_name">Hindu</option>
					<option value="Christian" name="religion_name" id="religion_name">Christian</option>
					<option value="Muslim" name="religion_name" id="religion_name">Muslim</option>
				</select></td>
				</tr>
				</table>
				</center><br>
				<center><input type="submit"  class="btn-primarys" style="padding:10px;border-radius: 10px;" name="edit_profile_button" id="edit_profile_button" value="Add"></center>
			</form>
		</div>
		</div>
		</div>
	
	<?php
		$query=mysqli_query($con,"SELECT * FROM `tbl_userdetails` where login_id=$user_id ORDER BY wedding_id DESC")or die(mysqli_error($con));
		while ($row=mysqli_fetch_array($query)) {
	?>	
	<section class="section w-details-area center-text">
		<div class="containers">
			<div class="row">
				<div class="col-sm-1"></div>
				<div class="col-sm-10">
					<div class="heading">
						<h3 class="title">Wedding Details</h3>
						<span class="heading-bottom"><i class="icon icon-star"></i></span>
						<h5>Wedding ID: &nbsp;&nbsp;&nbsp;<?php echo $row['wedding_user_id']?></h5>
					</div>
					
					<div class="wedding-details margin-bottom">
					
						<div class="w-detail right">
							<img src="upload/<?php echo $row['bride_photo']?>" style="width:120px;height:150px;">
							<h4 class="title"><?php echo $row['bride_name']?></h4>
							<p><?php echo $row['bride_address']?></p>
						</div><!-- w-detail -->
						
						<div class="w-detail left">
						<img src="upload/<?php echo $row['groom_photo']?>" style="width:120px;height:150px;">
							<h4 class="title"><?php echo $row['groom_name']?></h4>
							<p><?php echo $row['groom_address']?></p>
						</div><!-- w-detail -->
						
						<div class="w-detail right">
							<i class="icon icon-ciurclke"></i>
							<h4 class="title">Wedding Date</h4>
							<p><?php echo $row['wed_date']?></p>
						</div><!-- w-detail -->
						
						<div class="w-detail left">
							<i class="icon icon-camera"></i>
							<h4 class="title">Wedding Venue</h4>
							<p><?php echo $row['wed_hall']?><br><?php echo $row['wed_hall_address1']?><br><?php echo $row['wed_hall_address2']?><br><?php echo $row['wed_hall_pincode']?></p>
						</div><!-- w-detail -->
						
					</div><!-- wedding-details -->
					
				</div><!-- col-sm-10 -->
			</div><!-- row -->
		</div><!-- container -->
	</section><!-- section -->
	
						<?php
							}
						?>
<style>
.tbl-row{
	padding:10px;
}
.containers{
	background: #fff;
    box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.3);
    transition: 0.5s;
	padding-top:20px;
	padding-bottom:20px;
	margin:20px;
	margin-left:150px;
	margin-right:150px;
}
</style>	
		
		
	<section class="section ceremony-area center-text">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					
					<div class="heading">
						<h2 class="title">Wedding</h2>
						<span class="heading-bottom"><i class="color-white icon icon-star"></i></span>
					</div>

					<div class="ceremony margin-bottom">
						<p class="desc">We assist our clients in creating memorable, magical 
						celebrations that exceed expectations. Our personal approach ensures the weddings we 
						plan are meaningful and truly reflect our clients as individuals, as couples, and states 
						something about their shared values and sense of style.</p>
						
					</div>
					
				</div><!-- col-sm-10 -->
			</div><!-- row -->
		</div><!-- container -->
	</section><!-- section -->
	
	
	<footer>
		<div class="container center-text">
			
			<div class="logo-wrapper">
				<a class="logo" href="#"><img src="../images/logo-black.png" alt="Logo Image"></a>
				<i class="icon icon-star" style="color:#E45F74;"></i>
			</div>
			<p><h4>Join us as we celebrate life and love.</h4></p>
			<i class="icon icon-heart" style="color:#E45F74;"></i>
			<br>
			<ul class="footer-links">
				<li><a href="user_home.php">HOME</a></li>
				<li><a href="user_packages.php">PACKAGES</a></li>
				<li><a href="cart.php">CART</a></li>
				<li><a href="paid_packages.php">PAID</a></li>
				<li><a href="logout.php" >SIGN OUT</a></li>
			</ul>
			<br>
			<ul class="social-icons">
				<li><a href="#"><i class="icon icon-twitter"></i></a></li>
				<li><a href="#"><i class="icon icon-instagram"></i></a></li>
				<li><a href="#"><i class="icon icon-pinterest"></i></a></li>
				<li><a href="#"><i class="icon icon-tripadvisor"></i></a></li>
			</ul><br>

		
		<div></div>
		</div><!-- container -->
	</footer>
	<!-- SCIPTS -->
	<script src="../common-js/jquery-3.1.1.min.js"></script>
	<script src="../common-js/tether.min.js"></script>
	<script src="../common-js/bootstrap.js"></script>
	<script src="../common-js/jquery.countdown.min.js"></script>
	<script src="../common-js/jquery.fluidbox.min.js"></script>
	<script src="../common-js/scripts.js"></script>
	
</body>
</html>