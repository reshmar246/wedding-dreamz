 <?php
include 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}
if(isset($_POST['submit'])) {
	
	$lid=$_GET['lid'];
	$rid=$_GET['rid'];
	$reg_name = $_POST['reg_name'];
	$reg_place = $_POST['reg_place'];
	$reg_phone = $_POST['reg_phone'];
	$username=$_POST['username'];
	
	$results = mysqli_query($con, "UPDATE `tbl_registration` SET `reg_name`='$reg_name',`reg_place`='$reg_place',`reg_phone`='$reg_phone' WHERE `reg_id`='$rid'");
	
	$resultss = mysqli_query($con, "UPDATE `tbl_login` SET `username`='$username' WHERE `login_id`='$lid'");
	
	echo "<script>alert('Profile updated successfully');window.location.href='user_profile.php';</script>";
	
}	
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
  <!---scripts-->	
    <script src="../common-js/jquery-3.2.1.min.js"></script>
	<script src="../common-js/oh-autoval-script.js"></script>
    <link href="../common-css/oautoval-style.css" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="../common-css/bootstrap.css" rel="stylesheet">
	<link href="../common-css/fluidbox.min.css" rel="stylesheet">
	<link href="../common-css/font-icon.css" rel="stylesheet">
	<link href="../common-css/styles.css" rel="stylesheet">
	<link href="../common-css/responsive.css" rel="stylesheet">
	<link href="../common-css/header_style.css" rel="stylesheet">
	<link href="../common-css/autoval-style.css" rel="stylesheet">
</head>
<body>
<style>
.tbl-row{
	padding:10px;
}
</style>	
    <?php include 'header.php'; ?>
	
	<div></div>
	<div class="div-main-slider" style="position:relative;">
	<div class="div-content" style="padding:30px;padding-top:35px;padding-left:70px;">
		 
		 
		 <div class="content-wrapper">
		<?php
		include 'conn.php';
			
			$id=$_GET['rid'];
			$query=mysqli_query($con,"SELECT * FROM `tbl_login`,`tbl_registration` WHERE `tbl_login`.login_id=`tbl_registration`.login_id AND `tbl_registration`.reg_id=$id");
			while($row=mysqli_fetch_array($query))
			{
		?>
		<div class="main-prof">
			<div class="profile-main">
			<center><h5><u>EDIT DETAILS</u></h5><br>
				<form name="myform" method="post" class="oh-autoval-form" >
				<table>
					<tr>
						<td class="tbl-row-hd">Name</td>
						<td class="tbl-row-hd">:&nbsp; <input type="text" class="av-name" av-message="Invalid Name"  name="reg_name" value="<?php echo $row['reg_name']?>"></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Place</td>
						<td class="tbl-row-hd">: &nbsp;<input type="text" class="av-name" av-message="Invalid Place"  name="reg_place" value="<?php echo $row['reg_place']?>"></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Phone</td>
						<td class="tbl-row-hd">:&nbsp; <input type="text"  class="av-mobile" av-message="Invalid Mobile Number" name="reg_phone" value="<?php echo $row['reg_phone']?>"></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Email-id</td>
						<td class="tbl-row-hd">: &nbsp;<input type="text"  class="av-email" av-message="Invalid email address" name="username" value="<?php echo $row['username']?>"></td>
					</tr>
					
				</table>
				<input type="submit" name="submit"  class="btn-primary" value="EDIT">
				</form>
			</center>	
			</div>
		</div>
		<?php
		}
		?>
		
	
        </div>
        <!-- content-wrapper ends -->
		
<style>

.btn-primary {
    color: #fff;
    background-color: #5969ff;
    border-color: #5969ff;
	    font-size: 14px;
    padding: 5px 12px;
    border-radius: 2px;
margin-right:30px;
	margin-top:50px;
}
.btn-primary:hover{
    color: #fff;
    background-color: #6610f2;
    border-color:#6610f2;
}
</style>   
  </div>
        </div>
			
    
<style>
.profile-main{
	position:relative;
	padding:20px;
	margin:10px;
	padding-top:35px;
	margin-left:280px;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.1);
	transition: 0.5s;
	float:left;
	width:500px;
	height:500px;
	font-size:17px;
}

.main-prof{
	background-image:url(../images/hd2.jpeg);
	position:relative;
	width:100%;
}
.profile-img{
	float:left;
	margin-left:180px;
	width:100px;
	height:100px;
}
.tbl-row-hd{
	padding:5px;
}
</style>     


		</div>
	</div><!-- main-slider -->
	
	
	
	<!-- SCIPTS -->
	<script src="../common-js/jquery-3.1.1.min.js"></script>
	<script src="../common-js/tether.min.js"></script>
	<script src="../common-js/bootstrap.js"></script>
	<script src="../common-js/jquery.countdown.min.js"></script>
	<script src="../common-js/jquery.fluidbox.min.js"></script>
	<script src="../common-js/scripts.js"></script>
	
</body>
</html>