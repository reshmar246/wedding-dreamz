<?php
include 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}

$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(isset($_POST['btn_remove_cart_food'])){
	$item_id=$_POST['cart_item'];
	$cart_id=$_POST['item_cart'];
	mysqli_query($con, "DELETE FROM `tbl_add_cart` WHERE `item_id`='$item_id' and `cart_id`='$cart_id' and `package_id`='1'");
	echo "<script>alert('Item has been successfully removed..!');</script>";
}
if(isset($_POST['btn_remove_cart_hall'])){
	$item_id=$_POST['cart_item'];
	$cart_id=$_POST['item_cart'];
	 mysqli_query($con, "DELETE FROM `tbl_add_cart` WHERE `item_id`='$item_id' and `cart_id`='$cart_id' and `package_id`='2'");
	echo "<script>alert('Item has been successfully removed..!');</script>";
}
if(isset($_POST['btn_remove_cart_studio'])){
	$item_id=$_POST['cart_item'];
	$cart_id=$_POST['item_cart'];
	mysqli_query($con, "DELETE FROM `tbl_add_cart` WHERE `item_id`='$item_id' and `cart_id`='$cart_id' and `package_id`='3'");
	echo "<script>alert('Item has been successfully removed..!');</script>";
}
if(isset($_POST['btn_remove_cart_dress'])){
	$item_id=$_POST['cart_item'];
	$cart_id=$_POST['item_cart'];
	mysqli_query($con, "DELETE FROM `tbl_add_cart` WHERE `item_id`='$item_id' and `cart_id`='$cart_id' and `package_id`='4'");
	echo "<script>alert('Item has been successfully removed..!');</script>";
}
?>


<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="../common-css/bootstrap.css" rel="stylesheet">
	<link href="../common-css/fluidbox.min.css" rel="stylesheet">
	<link href="../common-css/font-icon.css" rel="stylesheet">
	<link href="../common-css/styles.css" rel="stylesheet">
	<link href="../common-css/responsive.css" rel="stylesheet">
</head>
<body>
	
	<?php include 'header.php'; ?>
	
	
<style>
body {
	font-family: Arial;
	color: #211a1a;
	font-size: 0.9em;
}
.cart-rows{
	position:absolute;
	padding:20px;
	padding-top:10px;
	margin:5px;
	background: #fff;
	width:100%;
}
.cart-table{
	position:relative;
	padding:20px;
	padding-top:10px;
	margin:5px;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.3);
	transition: 0.5s;
	float:left;
	width:100%;
	height:180px;
}
.cart-desc-img{
	width:230px;
	height:160px;
	float:left;
}
.details{
	position:relative;
	margin-left:260px;
	width:200px;
	height:100px;
	font-size:17px;
}
.cart-buttons{
	padding-top:5px;
	padding-left:280px;
}
.cart-buttons-remove{
	width:150px;
	height:20px;
	padding:5px;
}
.buttons{
	position:relative;
	padding-top:10px;
	padding-left:280px;
	width:400px;
	height:30px;
}
.btn-primary {
	background: #108FB8;
	color: #fff;
	border: 1px solid #108FB8;
}
.btn-primary:hover {
	background: #277088;
	color: #fff;
	border: 1px solid #277088;
}
.btn {
	margin:10px;
	font-family: "Work Sans", Arial, sans-serif;
	font-size: 15px;
	font-weight: 400;
	border-radius: 10px;
	transition: 0.2s;
	padding: 8px 20px;
}
.btnremove{
	background: #F7F9F9;
	color: black;
	border: 1px solid #F7F9F9;
	font-size: 17px;
	font-weight: 500;
	border-radius: 10px;
	transition: 0.2s;
	padding: 7px 18px;
	margin:5px;
}
.btnremove:hover{
	background: #D7DBDD;
	color: black;
	border: 1px solid #D7DBDD;
}
.cart-empty{
	width: 900px;
	background-color: #fff;
    border-radius: 2px;
    box-shadow: 0 1px 2px 0 rgba(0,0,0,.2);
	float:left;margin-left:35px;margin-right:20px;margin-bottom:60px;
}
.cart-empty-img{
	width: 170px;
	height:130px;
	padding-top:30px;
	margin:10px;
	position:relative;
}
.cart-det{
	width: 300px!important;
	display: inline-block;
    vertical-align: top;
    margin-left: 20px;
    position: relative;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.3);
}
._13wOiu {
    background: var(--color-white-bg);
    border-radius: 2px;
    min-height: 47px;
    box-shadow: 0 1px 1px 0 rgba(0,0,0,0.2);
}
._2huYiT, ._2twTWD {
    border-bottom: 1px solid grey;
}
._2huYiT {
    display: block;
    text-transform: uppercase;
    padding: 13px 24px;
    font-weight: var(--font-medium);
    font-size: var(--font-size-16);
    color: var(--color-grey-grade4);
    min-height: 47px;
    border-radius: 2px 2px 0 0;
}
._2twTWD {
    padding: 0 24px;
    font-size: 15px;
}
._3xFQAD {
    border-top: 1px dashed #e0e0e0;
    margin-bottom: 20px;
}
</style>	
	<!-- CONTENT -->
	<div class="content" style="padding:30px;min-width: 1120px;margin-bottom:20px;">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h3><center>Shopping Cart</center></h3>
				</div><!-- col -->
			</div><!-- row -->
		</div><!-- container --><br><br>
		
		<div class="container" style="float:left;width:900px;margin-left:35px;margin-right:20px;margin-bottom:60px;">
			<div class="row">
						
						<center><img class="cart-empty-img" src="../images/cart.png" style="margin-left:300px;"><br>
						<h5 style="margin-left:300px;">Your Cart is Empty</h5></center>
				<div class="cart-rows">		
					<?php
						$total=0;$total1=0;$total2=0;$total3=0;$total4=0;
						$query=mysqli_query($con,"select * from tbl_add_cart where login_id=$user_id and cart_status=1 and order_status=0");
						while ($row=mysqli_fetch_array($query)) {
						$package_id = $row['package_id'];	
						$item_id = $row['item_id'];	
						$cart_id = $row['cart_id'];
						
					 
						 ?>	
					<?php
					if($package_id=='1'){
							$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_catering`.`food_name`,`tbl_catering`.`food_price` from `tbl_catering`,`tbl_image` where `tbl_catering`.`catering_id`=$item_id AND `tbl_image`.`item_img_id`= `catering_id` AND `tbl_image`.`package_id`=`tbl_catering`.`package_id` AND `tbl_image`.`image_status`=1");
							while($row2=mysqli_fetch_array($query2)){

					?>
				<div class="cart-table">
					<div class="cart-desc-img">
						<img src="../admin/upload_images/food/<?php echo $row2['image']?>" style="width:100%;height:100%;">
					</div>
					<div class="details">
						<?php echo $row2['food_name']?><br>
						<?php echo "₹ ".$p=$row2['food_price']?><br>
						Quantity: &nbsp;<?php echo $q=$row['cart_quantity']?><br>
						Wedding ID: &nbsp;<?php echo $row['wedding_id']?><br>
						Total Price: &nbsp; <?php echo "₹ ".$total1=$total1+$q*$p ?>
					</div>
					<div class="cart-buttons" style="margin-top:15px;margin-bottom:1px;padding:2px;padding-left:280px;">
						<form action="" method="post">
						<input type="hidden" name="cart_item" value="<?php echo $row['item_id'] ?>">
						<input type="hidden" name="item_cart" value="<?php echo $row['cart_id'] ?>">
						<input type="submit" name="btn_remove_cart_food" class="btnremove" value="X Remove" style="margin-top:5px;padding-top:3px;">
						</form>
					</div>		
				</div>
				<?php
					}
					}
					else if($package_id=='2'){
						$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_hall_decor`.stage_dec_name,`tbl_hall_decor`.stage_price  from tbl_hall_decor,tbl_image where `tbl_hall_decor`.`hall_id`=$item_id AND `tbl_image`.`item_img_id`= `hall_id` AND `tbl_image`.`package_id`=`tbl_hall_decor`.`package_id` AND `tbl_image`.`image_status`=1");
						while($row2=mysqli_fetch_array($query2)){
				?>
				<div class="cart-table">
					<div class="cart-desc-img">
						<img src="../admin/upload_images/hall/<?php echo $row2['image']?>" style="width:100%;height:100%;">
					</div>
					<div class="details">
						<?php echo $row2['stage_dec_name']?><br>
						<?php echo "₹ ".$p=$row2['stage_price']?><br>
						Wedding ID: &nbsp;<?php echo $row['wedding_id']?><br>
						Total Price: &nbsp; <?php echo "₹ ".$total2=$total2+$p ?>
					</div>
					<div class="cart-buttons">
						<form action="" method="post">
						<input type="hidden" name="cart_item" value="<?php echo $row['item_id'] ?>">
						<input type="hidden" name="item_cart" value="<?php echo $row['cart_id'] ?>">
						<input type="submit" name="btn_remove_cart_hall" class="btnremove" value="X Remove">
						</form>
					</div>		
				</div>
				<?php
					}
					}
					else if($package_id=='3'){
						$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_studio`.photo_package_name,`tbl_studio`.studio_price from tbl_studio,tbl_image where `tbl_studio`.`studio_id`=$item_id AND `tbl_image`.`item_img_id`= `studio_id` AND `tbl_image`.`package_id`=`tbl_studio`.`package_id` AND `tbl_image`.`image_status`=1");
						while($row2=mysqli_fetch_array($query2)){
				?>
				<div class="cart-table">
					<div class="cart-desc-img">
						<img src="../admin/upload_images/studio/<?php echo $row2['image']?>" style="width:100%;height:100%;">
					</div>
					<div class="details">
						<?php echo $row2['photo_package_name']?><br>
						<?php echo "₹ ".$p=$row2['studio_price']?><br>
						Wedding ID: &nbsp;<?php echo $row['wedding_id']?><br>
						Total Price: &nbsp; <?php echo "₹ ".$total3=$total3+$p ?>
					</div>
					<div class="cart-buttons">
						<form action="" method="post">
						<input type="hidden" name="cart_item" value="<?php echo $row['item_id'] ?>">
						<input type="hidden" name="item_cart" value="<?php echo $row['cart_id'] ?>">
						<input type="submit" name="btn_remove_cart_studio" class="btnremove" value="X Remove">
						</form>
					</div>		
				</div>
				<?php
					}
					}
					else if($package_id=='4'){
						$query2=mysqli_query($con,"select DISTINCT `tbl_image`.`image`,`tbl_dress`.`dress_name`,`tbl_dress`.`dress_price` from tbl_dress,tbl_image where `tbl_dress`.`dress_id`=$item_id AND `tbl_image`.`item_img_id`= `dress_id` AND `tbl_image`.`package_id`=`tbl_dress`.`package_id` AND `tbl_image`.`image_status`=1");
						while($row2=mysqli_fetch_array($query2)){
				?>
				<div class="cart-table">
					<div class="cart-desc-img">
						<img src="../admin/upload_images/dress/<?php echo $row2['image']?>" style="width:100%;height:100%;">
					</div>
					<div class="details">
						<?php echo $row2['dress_name']?><br>
						<?php echo "₹ ".$p=$row2['dress_price']?><br>
						Wedding ID: &nbsp;<?php echo $row['wedding_id']?><br>
						Total Price: &nbsp; <?php echo "₹ ".$total4=$total4+$p ?>
					</div>
					<div class="cart-buttons">
						<form action="" method="post">
						<input type="hidden" name="cart_item" value="<?php echo $row['item_id'] ?>">
						<input type="hidden" name="item_cart" value="<?php echo $row['cart_id'] ?>">
						<input type="submit" name="btn_remove_cart_dress" class="btnremove" value="X Remove">
						</form>
					</div>		
				</div>
				<?php
					}
					}
					}
				?>	
						
				</div>
		
			</div><!-- row -->
		</div><!-- container -->
		
	<div class="cart-det">
		<div class="_13wOiu">
			<span class="_2huYiT">Price details</span><br>
			<div class="_2twTWD">
			<div class="hJYgKM">Amount Payable :&nbsp;<span><?php echo $total=$total1+$total2+$total3+$total4;?></span></div><br>
				<div class="_3xFQAD">
			<div class="hJYgKM">
								<center><a href="payment.php?amount=<?php echo $total;?>"><input type="submit" name="btn_checkout" class="btn btn-primary" value="Checkout >>"></a> </center>
							
						</div>
		</div>
	</div>
	</div>
	</div>	
	</div><!-- CONTENT -->
	
	<!-- SCIPTS -->
	<script src="../common-js/jquery-3.1.1.min.js"></script>
	<script src="../common-js/tether.min.js"></script>
	<script src="../common-js/bootstrap.js"></script>
	<script src="../common-js/jquery.countdown.min.js"></script>
	<script src="../common-js/jquery.fluidbox.min.js"></script>
	<script src="../common-js/scripts.js"></script>
	
</body>
</html>
