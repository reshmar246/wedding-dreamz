<?php
include_once 'conn.php';
session_start();
$q1=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}

?>

<html>
 
    <head>
    <title>Invoice</title>
        <style type="text/css">
        body {      
            font-family: Verdana;
        }
         
        div.invoice {
        border:1px solid #ccc;
        padding:10px;
        height:740pt;
        width:570pt;
        }
 
        div.company-address {
            border:1px solid #ccc;
            float:left;
            width:200pt;
        }
         
        div.invoice-details {
            border:1px solid #ccc;
            float:right;
            width:200pt;
        }
         
        div.customer-address {
            border:1px solid #ccc;
            float:right;
            margin-bottom:50px;
            margin-top:100px;
            width:200pt;
        }
         
        div.clear-fix {
            clear:both;
            float:none;
        }
         
        table {
            width:100%;
        }
         
        th {
            text-align: left;
        }
         
        td {
        }
         
        .text-left {
            text-align:left;
        }
         
        .text-center {
            text-align:center;
        }
         
        .text-right {
            text-align:right;
        }
         
        </style>
    </head>
 
    <body>
    <div class="invoice">
       <?php
			$query1=mysqli_query($con,"select * from tbl_registration,tbl_login WHERE tbl_login.login_id=tbl_registration.login_id AND tbl_login.login_role=1");
			while ($row1=mysqli_fetch_array($query1))
			{
		?>
		 <div class="company-address">
            <?php echo $row1['reg_name']?>
            <br />
            <?php echo $row1['reg_place']?>
            <br />
            <?php echo $row1['reg_phone']?>
            <br />
			<?php echo $row1['username']?>
        </div>
     
       <?php
			}
			$id=$_GET["id"];
			$query2=mysqli_query($con,"SELECT * FROM `tbl_payment` where pay_id=$id");
			while ($row2=mysqli_fetch_array($query2)) 
			{
		?>
        <div class="invoice-details">
            Invoice No.: <?php echo $row2['pay_id']?>
            <br />
            Date: <?php echo $row2['paid_date']?>
        </div>
        
       <?php
			}
			
		?> 
        <div class="customer-address">
            To:
            <br />
           <?php echo $user_id;?>
            <br />
           
        </div>
         
        <div class="clear-fix"></div>
            <table border='1' cellspacing='0'>
                <tr>
                    <th width=100>Wedding ID</th>
                    <th width=250>Package</th>
                    <th width=100>Total price</th>
                </tr>
 
            <?php
            $amount=$_GET["amount"];
            $query3=mysqli_query($con,"select * from tbl_registration,tbl_login WHERE tbl_login.login_id=tbl_registration.login_id AND tbl_login.login_role=1");
			while ($row3=mysqli_fetch_array($query3))
			{
              ?>		
				<tr>
                    <td><?php echo $row3['paid_date']?></td>
                    <td><?php echo $row3['paid_date']?></td>
                    <td class='text-right'><?php echo $row3['paid_date']?></td>
                </tr>
            <?php
}
             ?>
            <tr>
            	<td colspan='3' class='text-right'>TOTAL</td>
            	<td class='text-right'>₹ " .<?php echo $amount;?>. "</td>
            </tr>
            </table>
        </div>
    </body>
 
</html>