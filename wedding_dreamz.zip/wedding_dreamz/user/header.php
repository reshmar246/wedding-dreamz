
<style>
.main-menu li a:hover{
	border:1px solid black;
	color:black;
	transition:0.6s ease;
}
.div-signout{
    background-color: #b4245d;
	padding:5px;
	padding-left:7px;
	box-shadow: 0 1px 3px 0 rgba(0,0,0,.2);
    width: 100px;
	float:right;
	position:relative;
	color:#fff;
}
.div-signout:hover{
	background-color: #DC143C;
	transition:0.6s ease;
}
.div-main-signout{
	padding-top:26px;
	padding-right:30px;
}
.main-menu{
	padding-right:90px;
}
.user-avatar-md {
    height: 35px;
    width: 35px;
}
.rounded-circle {
    border-radius: 50%!important;
	background:transparent;
    vertical-align: middle;
    border-style: none;
}

.navbar-nav .dropdown-menu {
    position: static;
    float: none;
}

.dropdown-menu {
    background: #fff;
    font-size: 14px;
    color: #3d405c;
    border: 1px solid #e6e6f2;
}
.nav-user-dropdown {
}
.nav-user-dropdown {
    padding: 0px;
    min-width: 230px;
    margin: 0px;
}
.notification-dropdown, .connection-dropdown, .nav-user-dropdown {
    padding: 0px;
    margin: 0px;
}
.dropdown-menu-right {
    right: 0;
    left: auto;
}
.dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 1000;
    display: none;
    float: left;
    min-width: 10rem;
    padding: .5rem 0;
    margin: .125rem 0 0;
    font-size: 1rem;
    color: #212529;
    text-align: left;
    list-style: none;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid rgba(0,0,0,.15);
    border-radius: .25rem;
}
.nav-user-info {
    background-color: #5969ff;
    line-height: 1.4;
    padding: 12px;
    color: #fff;
    font-size: 13px;
    border-radius: 2px 2px 0 0;
}
.text-white {
    color: #fff!important;
}
.mb-0, .my-0 {
    margin-bottom: 0!important;
}
.nav-user-info .status {
    float: left;
    top: 7px;
    left: 0px;
}
.ml-2, .mx-2 {
    margin-left: .5rem!important;
}
.nav-user-dropdown .dropdown-item {
    display: block;
    width: 100%;
    padding: 12px 22px 15px;
    clear: both;
    font-weight: 400;
    color: #686972;
    text-align: inherit;
    white-space: nowrap;
    background-color: transparent;
    border: 0;
    font-size: 13px;
    line-height: 0.4;
}
 .fas {
    font-family: 'Font Awesome 5 Free';
    font-weight: 900;
}
.fa, .fas, .far, .fal, .fab {
    -moz-osx-font-smoothing: grayscale;
    -webkit-font-smoothing: antialiased;
    display: inline-block;
    font-style: normal;
    font-variant: normal;
    text-rendering: auto;
    line-height: 1;
}
.mr-2, .mx-2 {
    margin-right: .5rem!important;
}
.navbar-right-top .nav-item:last-child {
    border: none;
}

.navbar-right-top .nav-item {
    border-right: 1px solid #e6e6f2;
}
.nav-user {
}
.dropdown, .dropleft, .dropright, .dropup {
    position: relative;
}
.nav-link:hover{
	
background-color: #e72e77;
}
</style>
	
	  <header>
	  <div style="float:left;margin-left:30px;margin-right:5px;">
		<a href="#" style="margin-right:15px;padding:10px;font-size: 23px;text-transform: uppercase;font-weight: 600;color: #fff;">Wedding Dreamz</a>
	  </div>
		
		<div class="container" style="position:relative;margin-right:15px;">
			<div class="menu-nav-icon" data-nav-menu="#main-menu"><i class="icon icon-bars"></i></div>
			<ul class="main-menu visible-on-click" id="main-menu">
			<li><a href="user_home.php">HOME</a></li>
			<li><a href="user_packages.php">PACKAGES</a></li>
			<li><a href="cart.php">CART</a></li>
			<li><a href="paid_packages.php">PAID</a></li>
		<?php
				$query100=mysqli_query($con,"SELECT * FROM `tbl_registration` where login_id=$user_id")or die(mysqli_error($con));
				while ($row100=mysqli_fetch_array($query100)) {
			?>
			
			<li id="dropdown-user" class="dropdown" >
                <a href="#" data-toggle="dropdown" class="dropdown-toggle text-right" >
                    <span class="ic-user pull-right">
                        <img class="img-circle img-user media-object" src="../images/user2.jpg" >
                                                         
                    </span>
                </a>
                <div class="dropdown-menu dropdown-menu-md dropdown-menu-right panel-default" style="opacity: 1;margin-top:1px;">
					<div class="nav-user-info">
                       <h5 class="mb-0 text-white nav-user-name" style="text-transform: uppercase;margin-left:10px;"><?php echo $row100['reg_name']?> </h5>
                        <span class="status"></span><span class="ml-2">Available</span>
                    </div>                
                <ul class="head-list">
                    <li>
                        <a href="user_profile.php"><div style="float:left;margin-right:10px;"><img src="../images/profile.png" style="width:20px;height:20px;background:transparent;border:none;padding:4px;"></div> Profile</a>
                    </li>
                   <li>
                        <a href="change_password.php"><div style="float:left;margin-right:10px;"><img src="../images/key1.png" style="width:20px;height:20px;background:transparent;border:none;padding:4px;"></div>Change Password</a>
                    </li>
                    <li>
                        <a href="logout.php"><div style="float:left;margin-right:10px;"><img src="../images/logout.png" style="width:20px;height:20px;background:transparent;border:none;padding:4px;"></div> Logout</a>
                    </li>   
                </ul>
                               
                
                </div>
            </li>
					
		<?php
				}
		?>
        
			
            </ul>
            </div>
				
	</header>
	
	<div class="header-main-slider" style="background-color: #e72e77;width: 100%;height:75px;">
		<!-- <div class="div-main-signout">
		<div class="div-signout">
			
		</div>
	</div>-->
			
	</div><!-- main-slider -->
	
<style>
#dropdown-user {
    float: right;
	background-color: #e72e77;
}
.dropdown-toggle{
	background-color: #e72e77;
}
@media (max-width: 760px)
#dropdown-user{
    position: static;
}
#dropdown-user>a, #dropdown-user>a:focus {
    background-color: #e72e77 !important;
    color: #d9d9d9;
}
#dropdown-user>a, #dropdown-user>a:focus {
    background-color: ##e72e77!important;
    color: #677882;
}
 .open>a, .open>a:focus, .open>a:hover {
    background-color: #eee;
    border-color: #337ab7;
}
.nav-user-info {
    background-color: 	 #e72e77;
    line-height: 1.4;
    padding: 5px;
	padding-left:10px;
    color: #fff;
	height:60px;
    font-size: 13px;
    border-radius: 2px 2px 0 0;
}
.text-white {
    color: #fff!important;
}
.mb-0, .my-0 {
    margin-bottom: 0!important;
}
.nav-user-info .status {
    float: left;
    top: 5px;
    left: 0px;
}

#dropdown-user>a {
    display: table-cell;
    padding: 2px;
    height: 55px;
    color: #8f9ea6;
    transition: all .4s;
}
#dropdown-user .ic-user {
    font-size: 1.5em;
    height: 5px !important;
    line-height: 59px;
}
#dropdown-user .ic-user {
    font-size: 1.5em;
    height: 55px;
    line-height: 59px;
}
.pull-right {
    float: right;
}
.pull-right {
    float: right!important;
}
.img-user {
    width: 32px;
    height: 32px;
    box-shadow: 0 0 0 2px rgba(0,0,0,0);
	padding-top:0px;
}

.media-object {
    display: block;
}
.img-circle {
    border-radius: 50%;
}
@media (max-width: 760px)
 .dropdown-menu {
    width: auto;
    left: 10px;
    right: 10px;
}
.open>.dropdown-menu {
    display: block;
}
.dropdown-menu {
    z-index: 10000 !important;
}
.dropdown-menu-md {
    min-width: 200px;
}
.dropdown-menu-right {
    left: auto;
    right: 0;
}
.dropdown-menu {
    font-size: 14px;
    box-shadow: 0 3px 7px rgba(0,0,0,.3);
    margin: 0;
    padding: 0;
    border: 0;
}
.dropdown-menu :hover{
	border:none;
}
.head-list {
    list-style: none;
    padding: 0;

    margin: 0;
}
.dropdown-menu li:not(.active) a:not(:hover) {
    color: #4d627b;
}
 .head-list li a {
    display: block;
	border:none;
	width:200px;
	position:relative;
    padding: 12px 15px;
    transition: background .3s;
}
 .head-list li a:hover {
    display: block;
	border:none;
	width:200px;
	background-color: #FFFAFA	;
	position:relative;
    padding: 12px 15px;
    transition: background .3s;
}
.pad-all {
    padding: 15px;
}

.text-right {
    text-align: right;
}
.btn-purple{
    background-color:	#FFC0CB;
    border-color:	#FFC0CB !important;
    color: #fff;
}
.btn {
    cursor: pointer;
    background-color: 	#FFC0CB;
    color: inherit;
    padding: 6px 12px;
    border: 1px solid transparent;
    font-size: 13px;
    line-height: 1.475;
    vertical-align: middle;
    transition: all .25s;
}
.btn-purple :hover{
background-color: #FFC0CB;
}
</style>
