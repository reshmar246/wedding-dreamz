<?php
include 'db.php';
include("dbconnection.php");
$db = new DbConnection;
session_start();
if (!(isset($_SESSION['login_id']))) {
   header('location:../index.php');
}
$login_id=$_SESSION['login_id'];
$username=$_SESSION['username'];
//echo $login_id;
//echo $email;
if (isset($_POST['submitsn'])) {
    $otp=$_POST['otp'];
   // $email=getSession('email');
    // print_r($email);
    // return;
    $sql="select * from tbl_otp where email='$username' and status=1 and count>=0";
    // print_r($sql);
    //  return;
    $result=mysqli_query($con,$sql);
   
    if(mysqli_num_rows($result)>0){
         	$row=mysqli_fetch_assoc($result);
            $a=$row['otp'];
            $co=$row['count'];
// print_r($co);
// return;
//      echo $co." ".$a." ".$otp;
//     if($co>0)
//     {
        
    
        if($a==$otp)
 	    {
             $sql1="UPDATE `tbl_otp` SET `status`=0,`count`=0 WHERE `email`='$username'";
             mysqli_query($con,$sql1);
             echo "<script>alert('Authentication Success ');window.location='changepassword.php';</script>";

         
         }
         else
         {

             $sql2="UPDATE `tbl_otp` SET `count`= count-1 WHERE `email`='$username'";
             //print_r($sql2);
             //return;
             mysqli_query($con,$sql2);
             echo "<script>alert('Wrong OTP ');window.location='otpconfirm.php';</script>";
         }
     }
  else
     {
        $sql3="UPDATE `tbl_otp` SET `count`=0,`status`=0 WHERE `email`='$username'";
        //print_r($sql2);
        //return;
        mysqli_query($con,$sql3);
        echo "<script>alert('OTP Expired ');window.location='../index.php';</script>";
     }
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
	<title>Forgot Password</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</head>
<body>
<div class="div-full">
	<form method="post">
<div class="container" style="padding-top: 100px;position: relative;">
	<div class="row justify-content-center"> 
	<div class="col-md-6 col-md-offset-3" align="center" style="padding-top:100px;padding-bottom:70px;position: relative;width:100%;height:auto;padding-left:0px;padding-right:0px;margin:0px;">
		    <input type="text" class="form-control" id="otp" name="otp" placeholder="ENTER YOUR OTP">
		<br>
		<input type="submit"     class="btnsubmit" value="ENTER" name="submitsn"><br><br>
                <a href="../index.php">BACK TO HOME PAGE</a>
		<p id="response"></p>

		</div>
	</div>
	</div>
</form>
</div>
<style>
.row{
	width:500px;
    height: auto;
    background-color: #051019;
    opacity: 0.9;
    color: #fff;
    margin-top:18px;
    margin-left: 270px;
    position: relative;
	padding:0px;
    box-sizing: border-box;
  
}
.div-full{
    height: 100vh;
	margin:0px;
    position: relative;
    opacity:0.9;
    background-image: url(../images/pic13.jpg);
    background-size: cover;
    color: #fff;
}
.btnsubmit{
	border: none;
    outline: none;
    height: 40px;
	width:90px;
    background: #e72e77;;
    color: #fff;
    font-size: 16px;
    border-radius: 10px;
}
	
</style>
</body>
</html>