<form action="mail.php" method="post">
Email:<input type="text" name="email">
<input type="submit" name="submit" value="submit">
</form>
