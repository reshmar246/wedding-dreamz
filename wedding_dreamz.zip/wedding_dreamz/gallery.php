<?php
include 'conn.php';

?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="common-css/bootstrap.css" rel="stylesheet">
	<link href="common-css/fluidbox.min.css" rel="stylesheet">
	<link href="common-css/font-icon.css" rel="stylesheet">
	<link href="common-css/styles.css" rel="stylesheet">
	<link href="common-css/responsive.css" rel="stylesheet">
	<!--script-->
	 <script src="common-js/mail.js"></script>
</head>
<body>
	<header>
		<div class="container">
			<a class="logo" href="#"><img src="images/logo-white.png" alt="Logo"></a>
			<div class="menu-nav-icon" data-nav-menu="#main-menu"><i class="icon icon-bars"></i></div>
			<ul class="main-menu visible-on-click" id="main-menu" style=" font-weight: 500;font-family: 'Bitter', serif;font-size:15px;">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php" >GALLERY</a></li>
				<li><a href="register.php" >SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul><!-- main-menu -->
		</div><!-- container -->
	</header>
	<div class="main-slider"  style="background-image:url(images/pic15.jpg);height:550px;">
		<div class="display-table center-text">
			<div class="display-table-cell">
				<div class="slider-content">
				    <i class="small-icon icon icon-tie"></i>
					<h3 class="pre-title">Wedding Dreamz</h3>
					<p><h4>Join us as we celebrate life and love.</h3></p>
				</div><!-- slider-content-->
			</div><!--display-table-cell-->
		</div><!-- display-table-->
	</div><!-- main-slider -->
		
	
	
	
	<section class="section galery-area center-text">
		

			<style>
body {
	font-family: Arial;
	color: #211a1a;
	font-size: 0.9em;
}
.cart-table{
	position:relative;
	padding:20px;
	padding-top:10px;
	margin:5px;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.3);
	transition: 0.5s;
	float:left;
	width:100%;
	height:200px;
}
.cart-desc-img{
	width:260px;
	height:180px;
	float:left;
}
.details{
	position:relative;
	margin-left:280px;
	margin-top:10px;
	width:800px;
	height:100%;
	font-size:17px;
}
</style>
	
	<!-- CONTENT
	<div class="content" style="padding:30px;">
		<div class="container">
			<div class="row">
			<div class="col-sm-12">
					<h2 class="title" style="font-size:35px;"><center>LATEST &nbsp;EVENTS</center></h2>
					<span class="heading-bottom"><i class="icon icon-star" style="color:#E45F74;"></i></span>
				</div>
			</div>
		</div><br><br>
		
		<div class="container">
			<div class="row">
			<?php
				include 'conn.php';
				$query=mysqli_query($con,"select * from tbl_event");
				while ($row=mysqli_fetch_array($query)) {
			?>
				<div class="cart-table">
					<div class="cart-desc-img">
						<img src="images/<?php echo $row['image']?>" style="width:100%;height:100%;">
					</div>
					<div class="details">
						<b><?php echo $row['groom_name']?> </b>&nbsp;<i class="icon icon-heart" style="color:#E45F74;"></i>&nbsp;<b><?php echo $row['bride_name']?> </b><br>
						<?php echo "Date : ".$row['wed_date']?><br>
						<b>Highlights: &nbsp;</b><?php echo $row['feedback']?><br>
					</div>		
				</div>
				
				<?php
					}
				?>
		</div>
	</div>
	</div> -->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					
					<div class="heading">
						<h2 class="title">Our Gallery</h2>
						<span class="heading-bottom"><i class="icon icon-star"></i></span>
					</div>
					
					<div class="image-gallery">
						<div class="row">
			<?php
				$query=mysqli_query($con,"SELECT DISTINCT * FROM `tbl_image` WHERE `package_id`=3    ORDER BY image_id DESC	")or die(mysqli_error($con));
				while ($row=mysqli_fetch_array($query)) {
			?>
							<div class="col-md-4 col-sm-6">
								<a href="admin/upload_images/studio/<?php echo $row['image'] ?>" data-fluidbox><img class="margin-bottom" style="width: 350px;height: 240px;" src="admin/upload_images/studio/<?php echo $row['image'] ?>" alt="Gallery Image"></a>
								
							</div><!-- col-sm-4 -->
							
			<?php
				}
			?>
							
						</div><!-- row -->								
					</div><!-- image-gallery -->
					
				</div><!-- col-sm-10 -->
			</div><!-- row -->
		</div><!-- container -->
	</section><!-- section -->
	
	<footer>
		<div class="container center-text">
			
			<div class="logo-wrapper">
				<a class="logo" href="#"><img src="images/logo-black.png" alt="Logo Image"></a>
				<i class="icon icon-star"></i>
			</div>
			<br><br><br>
			
			<ul class="footer-links">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php" >GALLERY</a></li>
				<li><a href="register.php">SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul>
			<br>
			<ul class="social-icons">
				<li><a href="#"><i class="icon icon-heart"></i></a></li>
				<li><a href="#"><i class="icon icon-twitter"></i></a></li>
				<li><a href="#"><i class="icon icon-instagram"></i></a></li>
				<li><a href="#"><i class="icon icon-pinterest"></i></a></li>
				<li><a href="#"><i class="icon icon-tripadvisor"></i></a></li>
			</ul><br>

		
		<div></div>
		</div><!-- container -->
	</footer>
	<!-- SCIPTS -->
	<script src="common-js/jquery-3.1.1.min.js"></script>
	<script src="common-js/tether.min.js"></script>
	<script src="common-js/bootstrap.js"></script>
	<script src="common-js/jquery.countdown.min.js"></script>
	<script src="common-js/jquery.fluidbox.min.js"></script>
	<script src="common-js/scripts.js"></script>
	
</body>
</html>