<?php
include 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}


if(isset($_POST['submit'])) 
{
	$oldpassword=md5($_POST['oldpwd']);
	$password=md5($_POST['newpwd']);
	$cpassword=md5($_POST['newpwd1']);
	$var1=mysqli_query($con, "SELECT `password` FROM `tbl_login` WHERE `login_id`='$user_id'");
	
	while($raw=mysqli_fetch_array($var1))
	{
		$pwd=$raw["password"];
	
	if ($oldpassword == $pwd) 
	{
		if ($oldpassword == $password) 
		{
			echo "<script>alert('Password match with the old password. Try a different one...');window.location.href='change_password.php';</script>";
		}
	
		else
		{
		
			if ($cpassword == $password) 
			{
				$resultss = mysqli_query($con, "UPDATE `tbl_login` SET `password`='$password' WHERE `login_id`='$user_id'");
			echo "<script>alert('Password changed successfully');window.location.href='employee_index.php';</script>";
	
		}
		else 
		{
			echo "<script>alert('Your password does not match');window.location.href='change_password.php';</script>";
		}
	}
	}
	else 
		{
			echo "<script>alert('Enter the old password..');window.location.href='change_password.php';</script>";
		}
	}
	
}	
?>
	
<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <!---scripts-->	
    <script src="../common-js/jquery-3.2.1.min.js"></script>
	<script src="../common-js/oh-autoval-script.js"></script>
    <link href="../common-css/oautoval-style.css" rel="stylesheet">
	
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
		<title>Wedding Dreamz</title>
</head>

<body>
    <!-- main wrapper -->
    <div class="dashboard-main-wrapper"  style="padding-top:5px;">
        <!-- navbar -->
		<?php include 'sidebar_emp.php'; ?>
		<!-- wrapper  -->
        <div class="dashboard-wrapper" style="position:relative;">
           
		<div class="main-prof">
			<div class="profile-main">
				<center><h3><u>Change Password</u></h3><br>
				<form name="myform" method="post" class="oh-autoval-form" >
				
				<table>
					<tr>
						<td class="tbl-row-hd">Old Password</td>
						<td class="tbl-row-hd">:&nbsp; <input type="password"  class="av-required" av-message="Enter old Password" name="oldpwd" placeholder="Old Password" required></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">New Password</td>
						<td class="tbl-row-hd">: &nbsp;<input type="password"  class="av-password" av-message="Enter valid Password " name="newpwd" placeholder="New Password" required></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Retype Password</td>
						<td class="tbl-row-hd">:&nbsp; <input type="password" class="av-password" av-message="Enter the same Password" name="newpwd1" placeholder="Retype Password" required></td>
					</tr>
				</table>
				<input type="submit" name="submit"  class="btn-primary" value="SUBMIT">
				</form>
			
			</center>	
			</div>
		</div>
	
		
<style>

.btn-primary {
    color: #fff;
    background-color: #5969ff;
    border-color: #5969ff;
	    font-size: 14px;
    padding: 5px 12px;
    border-radius: 2px;
margin-right:30px;
	margin-top:50px;
}
.btn-primary:hover{
    color: #fff;
    background-color: #6610f2;
    border-color:#6610f2;
}
</style>   
 
			
    
<style>
.profile-main{
	position:relative;
	padding:20px;
	margin:10px;
	padding-top:35px;
	margin-left:280px;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.1);
	transition: 0.5s;
	float:left;
	width:auto;
	height:500px;
	font-size:17px;
}

.main-prof{
	position:relative;
}
.profile-img{
	float:left;
	margin-left:180px;
	width:100px;
	height:100px;
}
.tbl-row-hd{
	padding:5px;
}
</style>     

 
		</div>	
        
    </div>
    <!-- end main wrapper  -->
	
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
</body>
 
</html>