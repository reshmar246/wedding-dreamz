 <?php
include 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}
if(isset($_POST['submit'])) {
	
	$lid=$_GET['lid'];
	$rid=$_GET['rid'];
	$emp_name = $_POST['emp_name'];
	$emp_phone = $_POST['emp_phone'];
	$company_name = $_POST['company_name'];
	$company_phone = $_POST['company_phone'];
	$company_address_line1 = $_POST['company_address_line1'];
	$company_address_line2 = $_POST['company_address_line2'];
	$company_address_line3 = $_POST['company_address_line3'];
	$company_pincode = $_POST['company_pincode'];
	$package_id= $_POST['package_name'];
	$username=$_POST['username'];
	
	$results = mysqli_query($con, "UPDATE `tbl_register_emp` SET `emp_name`='$emp_name',`emp_phone`='$emp_phone',`company_name`='$company_name',`company_phone`='$company_phone',`company_address_line1`='$company_address_line1',`company_address_line2`='$company_address_line2',`company_address_line3`='$company_address_line3',`company_pincode`='$company_pincode',`package_id`='$package_id' WHERE `reg_emp_id`='$rid'");
	
	$resultss = mysqli_query($con, "UPDATE `tbl_login` SET `username`='$username' WHERE `login_id`='$lid'");
	
	echo "<script>alert('Profile updated successfully');window.location.href='employee_profile.php';</script>";
	
}	
?>

<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!---scripts-->	
    <script src="../common-js/jquery-3.2.1.min.js"></script>
	<script src="../common-js/oh-autoval-script.js"></script>
    <link href="../common-css/oautoval-style.css" rel="stylesheet">
	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
		<title>Wedding Dreamz</title>
</head>

<body>
    <!-- main wrapper -->
    <div class="dashboard-main-wrapper" style="padding-top:0px;">
        <!-- navbar -->
        
		<?php include 'sidebar_emp.php'; ?>
		
		
        <!-- wrapper  -->
        <div class="dashboard-wrapper" style="position:relative;">
            <div class="dashboard-ecommerce">
        <div class="content-wrapper">
		<?php
		include 'conn.php';
			$lid=$_GET['lid'];
	        $rid=$_GET['rid'];
			$query=mysqli_query($con,"SELECT * FROM `tbl_login`,`tbl_register_emp`,`tbl_package` WHERE `tbl_login`.login_id=`tbl_register_emp`.login_id AND `tbl_package`.package_id=`tbl_register_emp`.package_id AND login_role=3 AND `tbl_login`.login_id=$lid AND `tbl_register_emp`.reg_emp_id=$rid");
			while($row=mysqli_fetch_array($query))
			{
		?>
		<div class="main-prof">
			<div class="profile-main">
			<center><h3><u>EDIT DETAILS</u></h3><br>
				<form name="myform" method="post" class="oh-autoval-form" >
				<table>
					<tr>
						<td class="tbl-row-hd">Manager Name</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<input type="text" class="av-name av-required" av-message="Enter a valid Name" name="emp_name" value="<?php echo $row['emp_name']?>"></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Manager Mobile Number</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<input type="text"  class="av-mobile" av-message="Enter valid Mobile Number"  name="emp_phone" value="<?php echo $row['emp_phone']?>"></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Company Name</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<input type="text"  class="av-name av-required" av-message="Enter a valid Name" name="company_name" value="<?php echo $row['company_name']?>"></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Company Contact Number</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<input type="text"  class="av-mobile" av-message="Enter valid Mobile Number" name="company_phone" value="<?php echo $row['company_phone']?>"></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Address Line1</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<input type="text"  class="av-name av-required" av-message="Enter a valid Place"name="company_address_line1" value="<?php echo $row['company_address_line1']?>"></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Address Line2</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<input type="text"  class="av-name av-required" av-message="Enter a valid Place"name="company_address_line2" value="<?php echo $row['company_address_line2']?>"></td>
						
					</tr>
					<tr>
						<td class="tbl-row-hd">Address Line3</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<input type="text"  class="av-name av-required" av-message="Enter a valid Place"name="company_address_line3" value="<?php echo $row['company_address_line3']?>"></td>
					</tr>	
					<tr>
						<td class="tbl-row-hd">Pincode</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<input type="text" class="av-pincode" av-message="Enter a valid Pincode"  name="company_pincode" value="<?php echo $row['company_pincode']?>"></td>
					</tr>
					<tr>
						<td class="tbl-row-hd">Package </td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;
						 <select   name="package_name"   class="av-required" av-message="Select a Package" placeholder="Package" required="">
								<option selected value="<?php echo $row['package_id']?>" name="package_name" id="package_name"><?php echo  $row['package_name']?></option>
								 
								<option value="1" name="package_name" id="package_name">Catering</option>
								<option value="2" name="package_name" id="package_name">Hall Decoration</option>
								<option value="3" name="package_name" id="package_name">Studio</option>
								<option value="4" name="package_name" id="package_name">Dress</option>
						</select>
					</tr>
					<tr>
						<td class="tbl-row-hd">Email</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<input type="text"  class="av-email" av-message="Invalid email address"  name="username" value="<?php echo $row['username']?>"></td>
					</tr>
				
				</table>
				<input type="submit" name="submit"  class="btn-primary" value="EDIT">
				</form>
			</center>	
			</div>
		</div>
		<?php
		}
		?>
		
	
        </div>
        <!-- content-wrapper ends -->	
        </div>
        <!-- end wrapper  -->
    </div>
    <!-- end main wrapper  -->
	<style>
.profile-main{
	position:relative;
	padding:20px;
	margin:10px;
	padding-top:35px;
	margin-left:280px;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.1);
	transition: 0.5s;
	float:left;
	width:auto;
	height:auto;
	font-size:17px;
}

.main-prof{
	background-image:url(../images/hd2.jpeg);
	position:relative;
	width:100%;
}
.profile-img-main{
	float:left;
	
	position:relative;
	width:100%;
}
.profile-img{
	float:left;
	margin-left:180px;
	width:100px;
	height:100px;
	position:relative;
}
.tbl-row-hd{
	color:black;
	font-size:15px;
	padding:5px;
	padding-left:50px;
}
.tbl-row-hd1{
	color:black;
	font-size:15px;
	padding:5px;
	padding-left:10px;
}
</style>     

    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
</body>
 
</html>