	<?php
if(session_status()==PHP_SESSION_NONE)
{
	session_start();//Start the current session
}
if(session_destroy())//Destroy it! So we are logged out now
{ 
header("location:../signin.php");
}

?> 