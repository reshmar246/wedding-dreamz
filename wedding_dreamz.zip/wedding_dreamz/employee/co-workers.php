 <?php
include_once 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}

?>

<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    	
	<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="css/main.css">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
    <!-- calendar CSS
		============================================ -->
    <link rel="stylesheet" href="css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.print.min.css">
    <!-- x-editor CSS
		============================================ -->
    <link rel="stylesheet" href="css/editor/select2.css">
    <link rel="stylesheet" href="css/editor/datetimepicker.css">
    <link rel="stylesheet" href="css/editor/bootstrap-editable.css">
    <link rel="stylesheet" href="css/editor/x-editor-style.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="css/data-table/bootstrap-editable.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="modernizr-2.8.3.min.js"></script>
	
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
		<title>Wedding Dreamz</title>
</head>

<style>
.pagination {
	float:right;
	
  display: inline-block;
}

.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  border: 1px solid #ddd;
  background-color: #fff;
}

.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}

.pagination a:first-child {
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
}

.pagination a:last-child {
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
}

</style>

<body>
    <!-- main wrapper -->
    <div class="dashboard-main-wrapper" style="padding-top:5px;">
        <!-- navbar -->
		<?php include 'sidebar_emp.php'; ?>
        
	<!-- wrapper  -->
    <div class="dashboard-wrapper" style="position:relative;">
        <div class="container-fluid  dashboard-content">
<style>
button.pd-setting-ed {
    display: inline-block;
    margin-right: 5px;
}
.fa {
    display: inline-block;
    font: normal normal normal 14px/1 FontAwesome;
    font-size: inherit;
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
button.pd-setting-ed {
    padding: 5px 10px;
    font-size: 14px;
    border-radius: 3px;
    border: 1px solid rgba(0,0,0,.12);
    background: #f5f5f5;
}
table td {
    padding: 9px 7px;
    border-top: 1px solid #e9ecef;
}
.td-emp-img {
    max-width: 100%;
    width: 60px;
	height: auto;
}
</style>		
		<div class="row">
            <!-- ============================================================== -->
            <!-- basic table  -->
             <!-- ============================================================== -->
             <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <h5 class="card-header">Co-workers</h5>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table style="font-size:15px;" class="table table-striped table-bordered first" id="table" data-toggle="table"  data-search="true" >
                             <thead>
                                    <tr>
										<th data-field="Manager Name" data-editable="false">Manager Name</th>
										<th data-field="Company Name" data-editable="false">Company Name</th>
										<th data-field="Contact Number" data-editable="false">Contact Number</th>
                                        <th data-field="Email" data-editable="false">Email</th>
                                        <th data-field="Address" data-editable="false">Address</th>
                                        <th data-field="Package" data-editable="false">Package</th>
                                    </tr>
                                </thead>
								<tbody>
        <?php
		include 'conn.php';
   
		$record_per_page = 5;
		//$page = '';
		if(isset($_GET["page"]))
		{
			$page = $_GET["page"];
		}
		else
		{
			$page = 1;
		}

		$start_from = ($page-1)*$record_per_page;
		
			$query=mysqli_query($con,"SELECT * FROM `tbl_login`,`tbl_register_emp`,`tbl_package` WHERE `tbl_login`.login_id=`tbl_register_emp`.login_id  AND `tbl_package`.package_id=`tbl_register_emp`.package_id AND login_role=3  AND `tbl_login`.login_id <> $user_id  LIMIT $start_from, $record_per_page");
			while($row=mysqli_fetch_array($query))
			{
		?>
                                    <tr><td><?php echo $row['emp_name']?></td>
                                        <td><?php echo $row['company_name']?></td>
										<td><?php echo $row['company_phone']?></td>
										<td><?php echo $row['username']?></td>
										<td><?php echo $row['company_address_line1']?><br><?php echo $row['company_address_line2']?><br><?php echo $row['company_address_line3']?><br><?php echo $row['company_pincode']?></td>
                                        
                                        <td><?php echo $row['package_name']?></td>
										
                                    </tr>
		<?php
		}
		?>
		</tbody>
		</table>
        </div>
		
	<div class="pagination" align="center">
    <br />
    <?php
    $page_query = "SELECT count(`tbl_login`.login_id) FROM `tbl_login`,`tbl_register_emp`,`tbl_package` WHERE `tbl_login`.login_id=`tbl_register_emp`.login_id  AND `tbl_package`.package_id=`tbl_register_emp`.package_id AND login_role=3  AND `tbl_login`.login_id <> $user_id";
	$page_result = mysqli_query($con,$page_query);
    $row = mysqli_fetch_row($page_result);
	$total_records=$row[0];
    $total_pages = ceil($total_records/$record_per_page);
    
    $pagLink = "<div class='pagination'>";  
	for ($i=1; $i<=$total_pages; $i++) {  
             $pagLink .= "<a href='co-workers.php?page=".$i."'>".$i."</a>";  
	};  
	echo $pagLink . "</div>";  
?>
    
    
    </div>
        </div>
        </div>
        </div>
		<!-- end basic table  -->
		</div>
		</div>
        </div>
			
			
			
			
            <!-- footer -->
            <div class="footer">
                <div class="container-fluid">
                   
                </div>
            </div>
            <!-- end footer -->
			
        </div>
        <!-- end wrapper  -->
    </div>
    <!-- end main wrapper  -->
	
    <!-- jquery
		============================================ -->
    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <!-- data table JS
		============================================ -->
    <script src="js/data-table/bootstrap-table.js"></script>
    <script src="js/data-table/tableExport.js"></script>
    <script src="js/data-table/data-table-active.js"></script>
    <script src="js/data-table/bootstrap-table-editable.js"></script>
    <script src="js/data-table/bootstrap-editable.js"></script>
    <script src="js/data-table/bootstrap-table-resizable.js"></script>
    <script src="js/data-table/colResizable-1.5.source.js"></script>
    <script src="js/data-table/bootstrap-table-export.js"></script>
    <!--  editable JS
		============================================ -->
    <script src="js/editable/jquery.mockjax.js"></script>
    <script src="js/editable/mock-active.js"></script>
    <script src="js/editable/select2.js"></script>
    <script src="js/editable/moment.min.js"></script>
    <script src="js/editable/bootstrap-datetimepicker.js"></script>
    <script src="js/editable/bootstrap-editable.js"></script>
    <script src="js/editable/xediable-active.js"></script>
    <!-- Chart JS
		============================================ -->
    <script src="js/chart/jquery.peity.min.js"></script>
    <script src="js/peity/peity-active.js"></script>
    <!-- tab JS
		============================================ -->
    <script src="js/tab.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="js/main.js"></script>
	
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
</body>
 
</html>