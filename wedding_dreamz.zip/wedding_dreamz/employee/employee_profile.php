 <?php
include_once 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}

?>

<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
		<title>Wedding Dreamz</title>
</head>

<body>
    <!-- main wrapper -->
    <div class="dashboard-main-wrapper" style="padding-top:0px;">
        <!-- navbar -->
        
		<?php include 'sidebar_emp.php'; ?>
		
		
        <!-- wrapper  -->
        <div class="dashboard-wrapper" style="position:relative;">
            <div class="dashboard-ecommerce">
        <div class="content-wrapper">
		<?php
		include 'conn.php';
   
			$query=mysqli_query($con,"SELECT * FROM `tbl_login`,`tbl_register_emp`,`tbl_package` WHERE `tbl_login`.login_id=`tbl_register_emp`.login_id AND `tbl_package`.package_id=`tbl_register_emp`.package_id AND login_role=3 AND `tbl_login`.login_id=$user_id");
			while($row=mysqli_fetch_array($query))
			{
		?>
				
<style>
.btn-primary{
	margin-right:30px;
	margin-top:60px;
}
.btn-primary a{
    color: #fff;
    background-color: #5969ff;
    border-color: #5969ff;
	    font-size: 14px;
    padding: 9px 16px;
    border-radius: 2px;
}
.btn-primary:hover a{
    color: #fff;
    background-color: #6610f2;
    border-color:#6610f2;
}
</style>	


			<div style="float:right;" class="btn-primary">
				<a href="edit_profile.php?rid=<?php echo $row['reg_emp_id'] ?>&lid=<?php echo $row['login_id'] ?>"><i class="fas fa-edit" data-original-title="edit"  id="icon-edit" ></i>&nbsp;Edit Profile</a>
			</div>
			
		<div class="main-prof">
			<div class="profile-main">
				<center><h3><u>PROFILE</u></h3><br></center>
				<div class="profile-img-main">
				<div class="profile-img">
					<img src="../images/user2.jpg" style="position:relative;width70px;height:70px;">
				</div></div>
				<br>
				
			<h4><u>Manager Details</u></h4>
			<table>
					<tr>
						<td class="tbl-row-hd"><i class="fas fa-user" aria-hidden="true"></i>&nbsp;Name</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<?php echo $row['emp_name']?></td>
					</tr>
					<tr>
						<td class="tbl-row-hd"><i class=" fas fa-mobile-alt" aria-hidden="true"></i>&nbsp;&nbsp;Mobile Number</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<?php echo $row['emp_phone']?></td>
					</tr>
			</table>
			<h4><u>Company Details</u></h4>
			<table>
					<tr>
						<td class="tbl-row-hd"><i class="fas fa-user" aria-hidden="true"></i>&nbsp; Name</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<?php echo $row['company_name']?></td>
					</tr>
					<tr>
						<td class="tbl-row-hd"><i class=" fas fa-mobile-alt" aria-hidden="true"></i>&nbsp;&nbsp;Mobile Number</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<?php echo $row['company_phone']?></td>
					</tr>
					<tr>
						<td class="tbl-row-hd"><i class="fas fa-map-marker-alt" aria-hidden="true"></i>&nbsp;&nbsp;Address</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<?php echo $row['company_address_line1']?><br>&nbsp;&nbsp;&nbsp;<?php echo $row['company_address_line2']?><br>&nbsp;&nbsp;&nbsp;<?php echo $row['company_address_line3']?><br>&nbsp;&nbsp;&nbsp;<?php echo $row['company_pincode']?></td>
					</tr>
					<tr>
						<td class="tbl-row-hd"><i class="fas fa-th" aria-hidden="true"></i>&nbsp;&nbsp;Package </td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<?php echo $row['package_name']?></td>
					</tr>
					<tr>
						<td class="tbl-row-hd"><i class="fas fa-envelope" aria-hidden="true"></i>&nbsp;&nbsp;Email</td>
						<td class="tbl-row-hd1">&nbsp;:&nbsp;<?php echo $row['username']?></td>
					</tr>
				</table>
				
			</div>
		</div>
		<?php
		}
		?>
		</div>
	
        </div>
        <!-- content-wrapper ends -->
			
        </div>
        <!-- end wrapper  -->
    </div>
    <!-- end main wrapper  -->
	<style>
.profile-main{
	position:relative;
	padding:20px;
	margin:10px;
	padding-top:35px;
	margin-left:280px;
	background: #fff;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.1);
	transition: 0.5s;
	float:left;
	width:500px;
	height:auto;
	font-size:17px;
}

.main-prof{
	background-image:url(../images/hd2.jpeg);
	position:relative;
	width:100%;
}
.profile-img-main{
	float:left;
	
	position:relative;
	width:100%;
}
.profile-img{
	float:left;
	margin-left:180px;
	width:100px;
	height:100px;
	position:relative;
}
.tbl-row-hd{
	color:black;
	font-size:15px;
	padding:5px;
	padding-left:50px;
}
.tbl-row-hd1{
	color:black;
	font-size:15px;
	padding:5px;
	padding-left:10px;
}
</style>     

    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
</body>
 
</html>