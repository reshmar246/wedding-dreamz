<?php
include_once 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}

?>

<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
		<title>Wedding Dreamz</title>


</head>

<body>
    <!-- main wrapper -->
    <div class="dashboard-main-wrapper"  style="padding-top:5px;">
        <!-- navbar -->
		<?php include 'sidebar_emp.php'; ?>

     
	<!-- wrapper  -->
    <div class="dashboard-wrapper"  style="position:relative;">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">Wedding Details</h2>
                                <p class="pageheader-text"></p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
					
			
    <?php
			  	$id=$_GET["id"];
				$querys=mysqli_query($con,"SELECT * FROM `tbl_login`,`tbl_registration`,`tbl_userdetails` WHERE `tbl_login`.login_id=`tbl_registration`.login_id AND `tbl_userdetails`.wedding_id=$id AND `tbl_login`.login_id=`tbl_userdetails`.login_id AND login_role=2 ORDER BY wedding_id DESC");
			while ($row=mysqli_fetch_array($querys)) {
    ?>
                    <div class="rows" style="float:left;font-size:18px;position:relative;width:800px;height:400px;box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22);padding:10px;margin:20px;margin-left:30px;background-color:#fff;">
                        
						<div style="float:left;position:relative;font-size:17px;padding:10px;background-color:#fff;margin-left:80px;">
						<table>
							<tr>
								<td>Wedding ID</td>
								<td>: &nbsp;<?php echo $row['wedding_user_id']?></td>
							</tr>
							<tr>
								<td>User Name</td>
								<td>: &nbsp;<span style="text-transform:uppercase;"><?php echo $row['reg_name']?></td>
							</tr>
							<tr>
								<td>Wedding Date</td>
								<td>: &nbsp;<?php echo $row['wed_date']?></td>
							</tr>
							<tr>
								<td>Religion</td>
								<td>: &nbsp;<?php echo $row['religion_name']?></td>
							</tr>
							<tr>
								<td style="padding-top:0px;margin-top:0px;">Wedding Venue</td>
								<td>: &nbsp;<?php echo $row['wed_hall']?><br>
									&nbsp;&nbsp;&nbsp;<?php echo $row['wed_hall_address1']?><br>
									&nbsp;&nbsp;&nbsp;<?php echo $row['wed_hall_address2']?><br>
									&nbsp;&nbsp;&nbsp;<?php echo $row['wed_hall_pincode']?>
								</td>
							</tr>
						</div>	
					</div>
						
			<?php } ?>			
					
		
				
                </div>
                <!-- ============================================================== -->
	</div>	</div>		
	</div>		
					
	
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
</body>
 
</html>