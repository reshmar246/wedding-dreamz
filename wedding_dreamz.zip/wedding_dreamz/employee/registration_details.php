 <?php
include_once 'conn.php';
session_start();
$query=mysqli_query($con,"SELECT * FROM `tbl_login`");
$user_id=$_SESSION['id'];

if(!isset($_SESSION['username'])){
	header('location:../signin.php');
}



 if(isset($_POST['submit']))
    {
        $cname= $_POST['cname'];
		$mphone=$_POST['mphone'];
		$mname= $_POST['mname'];
        $address=$_POST['address'];
		$city=$_POST['city'];
		$state=$_POST['state'];
        $pincode= $_POST['pincode'];
        $package_id=$_POST['package_id'];
		$cphone=$_POST['cphone'];
		$password=md5($_POST['password']);
		$cpassword=md5($_POST['cpassword']);
		
		
		$var1="SELECT * FROM `tbl_login` where `login_id`='$user_id'";
		$var2=mysqli_query($con,$var1);
		
		while ($row1=mysqli_fetch_array($var2)) 
		{
			$username = $row1['username'];
			
			$document=$_FILES['emp_document']['name'];
			move_uploaded_file($_FILES['emp_document']['tmp_name'],"../admin/upload/document/".$document);
  
		if ($cpassword == $password) 
		{	
		$sql1="UPDATE `tbl_login` SET  `password`='$password',`login_status`=1 WHERE `login_id`='$user_id' and `username`='$username' and `login_role`=3";
		$result1=mysqli_query($con,$sql1);
			

		$logid="SELECT `login_id` FROM `tbl_login` WHERE  `login_id`='$user_id'";
		$result2=mysqli_query($con,$logid);
		while($row=mysqli_fetch_array($result2))
		{
			$l=$row["login_id"];
			$res = mysqli_query($con, "INSERT INTO `tbl_register_emp`(`login_id`, `emp_name`, `emp_phone`, `company_name`, `company_address_line1`, `company_address_line2`, `company_address_line3`, `company_pincode`, `license_document`, `package_id`, `company_phone`, `emp_reg_status`) 
			VALUES ('$l','$mname','$mphone','$cname','$address','$city','$state','$pincode','$document','$package_id','$cphone','1')");
        	echo "<script>alert('Registration Successful');window.location.href='employee_index.php';</script>";
	
		}
		
		
		}
		else {

        echo "<script>alert('Your password does not match');window.location.href='registration_details.php';</script>";
			
		}
		}
		
	}
	


?>

<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!---scripts-->
    <script src="../common-js/jquery-3.2.1.min.js"></script>
	<script src="../common-js/oh-autoval-script.js"></script>
	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <link href="../css/emp_reg.css" rel="stylesheet">
	<link href="../common-css/oautoval-style.css" rel="stylesheet">
	
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../images/favicon.png" type="image/png">
		<title>Wedding Dreamz</title>
<script type="text/javascript">
    function checkDOB() {
        var dateString = document.getElementById('dob').value;
        var myDate = new Date(dateString);
        var today = new Date();
        if ( myDate > today ) { 
            $('#dob').after('<p style="color:red;">You cannot enter a date in the future!.</p>');
            return false;
        }
        return true;
    }
</script>

</head>

<body>
    <!-- main wrapper -->
    <?php
				$query=mysqli_query($con,"SELECT * FROM `tbl_login` where 	login_id=$user_id")or die(mysqli_error($con));
				while ($row=mysqli_fetch_array($query)) {
			?>

	<div class="dashboard-main-wrapper">
        <!-- navbar -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="employee_index.php" style="font-size:20px;">Wedding Dreamz</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                           
                        </li>
           
				
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="../images/user2.jpg" alt="" class="user-avatar-md rounded-circle"></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name" style="text-transform: uppercase;">EMPLOYEE </h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="logout.php"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
			
                    </ul>
                </div>
            </nav>
        </div>
        <!-- end navbar -->
		
           
<style>
.home-cont{
	postion:relative;
	padding:10px;
	margin:5px;
	padding-left:20px;
	width:1080px;
	height:620px;
	z-index:1;
	background-image:url(../images/hd2.jpeg);
}
.ceremony{
	padding:20px;
	padding-top:150px;
}
.ceremony p{	
	font-size:20px;
}
.tbl-row-hd,.tbl-row-hd1{
	padding:5px;
}			
</style>
	  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="cards">
			

		<form name="addemp" id="addemp"  class="oh-autoval-form"  method="post" action="" enctype="multipart/form-data" style="font-size:15px;background-color:#fff;margin:20px;margin-left:80px;margin-right:80px;">

			
			<h5 class="card-header" >Add More Details</h5>
			<div class="card-body" style="padding-left:100px;">
			
			<h3>Username:&nbsp;<?php echo $row['username']?></h3><br>
			
			<h4><u>Enter Manager Details  </u></h4>
			<table class="card-body-table">
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Name</td>
				<td class="tbl-row-hd1" style="padding-left:45px;">:&nbsp; <input type="text" class="av-name av-required" av-message="Enter a valid Name" name="mname" id="button" placeholder="Manager Name" required=""></td>
			</tr>
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Mobile Number</td>
				<td class="tbl-row-hd1" style="padding-left:45px;">:&nbsp; <input type="text" class="av-mobile" av-message="Enter valid Mobile Number" name="mphone" id="button" placeholder="Mobile Number" required=""></td>
			</tr>
			</table>
			
			
			<h4><u>Enter Company Details</u></h4>
			<table class="card-body-table">
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Name</td>
				<td class="tbl-row-hd1">:&nbsp; <input type="text" class="av-name av-required" av-message="Enter a valid Name" name="cname" id="button" placeholder="Company Name" required=""></td>
			</tr>
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Address Line 1</td>
				<td class="tbl-row-hd1">:&nbsp; <input type="text" class="av-name av-required" av-message="Enter a valid Place" name="address" id="button" placeholder="Address Line 1" required=""></td>
			</tr>
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Address Line 2</td>
				<td class="tbl-row-hd1">:&nbsp; <input type="text" class="av-name av-required" av-message="Enter a valid Place" name="city" id="button" placeholder="Address Line 2" required=""></td>
			</tr>
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Address Line 3</td>
				<td class="tbl-row-hd1">:&nbsp; <input type="text" class="av-name av-required" av-message="Enter a valid Place" name="state" id="button" placeholder="Address Line 3" required=""></td>
			</tr>
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Pincode</td>
				<td class="tbl-row-hd1">:&nbsp; <input type="text" class="av-pincode" av-message="Enter a valid Pincode" name="pincode" id="button" placeholder="Pincode" required=""></td>
			</tr>
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Certificate of License</td>
				<td class="tbl-row-hd1">:&nbsp; <input type="file" class="av-docgroup" av-message="Upload a valid Document(.doc,.docx,.pdf,..)" name="emp_document" id="button1" placeholder="Document" required=""></td>
			</tr>
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Package</td>
				<td class="tbl-row-hd1">:&nbsp; 
				<select   name="package_id" id="button" class="av-required" av-message="Select a Package" placeholder="Package" style="width:250px;" required="">
					<option value="" name="designation" id="designation">--Select--</option>
					<option value="1" name="designation" id="designation">Catering</option>
					<option value="2" name="designation" id="designation">Hall Decoration</option>
					<option value="3" name="designation" id="designation">Studio</option>
					<option value="4" name="designation" id="designation">Dress</option>
				</select></td>
			</tr>
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Contact Number</td>
				<td class="tbl-row-hd1">:&nbsp; <input type="text" class="av-mobile" av-message="Enter valid Mobile Number" name="cphone" id="button" placeholder="Mobile Number" required=""></td>
			</tr>
			
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Password</td>
				<td class="tbl-row-hd1">:&nbsp; <input type="password" class="av-password" av-message="Enter Password with a capital letter,small letter,special character,number & min. 6 characters" name="password" id="button" placeholder="Password" required=""></td>
			</tr>
			<tr class="tbl-row-main">
				<td class="tbl-row-hd">Confirm Password</td>
				<td class="tbl-row-hd1">:&nbsp; <input type="password" class="av-password" av-message="Enter the same Password" name="cpassword" id="button" placeholder="Confirm Password" required=""></td>
			</tr>
			
			</table>
			</div>
			
			<center><input type="submit" value="Register" class="btn btn-primary" id="submit" name="submit"></center>
			<br>
		</form>
	
		</div></div></div>	
		
			
	<?php
				}
			?>	
	
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
</body>
 
</html>