<?php
include 'conn.php';
 session_start();
if (isset($_POST['submit']))
{
   $username=$_POST['username'];   
   $password=md5($_POST['password']);	
   $sql="select * from tbl_login where username='$username' and password='$password' ";
   $res=mysqli_query($con,$sql);  

   while($fetch=mysqli_fetch_array($res))
   {
	   
    if($fetch['login_role']==1) 
     {
		$_SESSION['id']=$fetch['login_id']; 
		$_SESSION['username']=$fetch['username'];
        header("location:./admin/admin_home.php");	
     }

     elseif($fetch['login_role']==2) 
     {
		$_SESSION['id']=$fetch['login_id']; 
		print_r($_SESSION['id']);
		$_SESSION['username']=$fetch['username'];	
        header("location:./user/user_home.php");
     }
	 elseif($fetch['login_role']==3) 
     {
		$_SESSION['id']=$fetch['login_id']; 
		$loginid=$fetch['login_id']; 
		print_r($_SESSION['id']);
		$_SESSION['username']=$fetch['username'];
		
		$loid="SELECT * FROM `tbl_login`,`tbl_register_emp` WHERE  `tbl_login`.login_id=$loginid and `tbl_login`.login_id=`tbl_register_emp`.login_id";
        $r2=mysqli_query($con,$loid);
		if(mysqli_num_rows($r2) == 0)
		{
			header("location:./employee/registration_details.php");
		}
		else
		{
			header("location:./employee/employee_index.php");
		}
     }
	 
	 }
	if(mysqli_num_rows($res) == 0){
		echo "<script>alert('Unauthorized Access....');window.location.href='signin.php';</script>";
	
	 }
}
?>


<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="common-css/bootstrap.css" rel="stylesheet">
	<link href="common-css/fluidbox.min.css" rel="stylesheet">
	<link href="common-css/font-icon.css" rel="stylesheet">
	<link href="common-css/main.css" rel="stylesheet">
	<link href="common-css/responsive.css" rel="stylesheet">
	<link href="css/signin.css" rel="stylesheet">
</head>
<body>
	<header>
		<div class="container">
			<a class="logo" href="#"><img src="images/logo-white.png" alt="Logo"></a>
			<div class="menu-nav-icon" data-nav-menu="#main-menu"><i class="icon icon-bars"></i></div>
			<ul class="main-menu visible-on-click" id="main-menu">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php" >GALLERY</a></li>
				<li><a href="register.php" >SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul><!-- main-menu -->
		</div><!-- container -->
	</header>
	<div class="m-slider">
		<div class="loginbox">
	  <h1>Login Here</h1><br>
	  <form name="myform" method="post">
			<input type="text" name="username" id="username" placeholder="Enter Username" required="" autocomplete="off">
			<input type="password" name="password" id="password" placeholder="Enter Password" required="" autocomplete="off"><br>
			<input type="submit" id="submit" name="submit"  value="LOGIN">
			<a href="mails/forgotpassword.php">Forgot password</a>
		</form>
	</div>
		</div>
	
	
	
	<!-- SCIPTS-->
	<script src="common-js/jquery-3.1.1.min.js"></script>
	<script src="common-js/tether.min.js"></script>
	<script src="common-js/bootstrap.js"></script>
	<script src="common-js/jquery.countdown.min.js"></script>
	<script src="common-js/jquery.fluidbox.min.js"></script>
	<script src="common-js/scripts.js"></script>
	
</body>
</html>