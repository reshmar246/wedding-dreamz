<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="common-css/bootstrap.css" rel="stylesheet">
	<link href="common-css/font-icon.css" rel="stylesheet">
	<link href="common-css/responsive.css" rel="stylesheet">
	<link href="common-css/styles2.css" rel="stylesheet">
</head>
<body>
	<header>
		<div class="container">
			<a class="logo" href="#"><img src="images/logo-white.png" alt="Logo"></a>
			<div class="menu-nav-icon" data-nav-menu="#main-menu"><i class="icon icon-bars"></i></div>
			<ul class="main-menu visible-on-click" id="main-menu">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php">GALLERY</a></li>
				<li><a href="register.php" >SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul><!-- main-menu -->
		</div><!-- container -->
	</header>
	<div class="main-slider">
		<div class="display-table center-text">
			<div class="display-table-cell">
				<div class="slider-content">
					<i class="small-icon icon icon-tie"></i>
					<h3 class="pre-title">Wedding Dreamz</h3>
					<p><h4>Join us as we celebrate life and love.</h3></p>
				</div><!-- slider-content-->
			</div><!--display-table-cell-->
		</div><!-- display-table-->
	</div><!-- main-slider -->
		
	<section class="regular-area">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					
					<div class="content">
					
						<div class="img-wrapper"><img src="images/regular-content-1-1000x650.jpg" alt="Content Image"></div>
						
						<h2 class="margin-top-btm">Wedding Dreamz</h2>
						<p class="margin-top-btm">A wedding is a ceremony where two people are united in marriage. 
						Wedding traditions and customs vary greatly between cultures, ethnic groups, religions, countries, and social classes. 
						Most wedding ceremonies involve an exchange of marriage vows by the couple, presentation of a gift (offering, rings, symbolic item, flowers, money), and a public proclamation of marriage by an authority figure or celebrant. 
						Special wedding garments are often worn, and the ceremony is sometimes followed by a wedding reception. 
						Music, poetry, prayers or readings from religious texts or literature are also commonly incorporated into the ceremony.</p>
						
						<h4 class="margin-top-btm">Weddings in India</h4>
						
						<p class="margin-top-btm">Weddings in India vary regionally, the religion and per personal preferences of the bride and groom. 
						They are festive occasions in India, and in most cases celebrated with extensive decorations, colors, music, dance, costumes and rituals that depend on the religion of the bride and the groom, as well as their preferences.
						India celebrates about 10 million weddings per year, of which about 80% are Hindu weddings.</p>
						
						<div class="quoto-area margin-top-btm">
							<h3 class="quoto"><i class="icon icon-quote"></i>
							“Love recognizes no barriers. It jumps hurdles, leaps fences, penetrates walls to 
							arrive at its destination full of hope.”</h3>
							<h5 class="name">Maya Angeluo</h5>
						</div>
						
						<div class="row">
							<div class="col-sm-6">
								<div class="img-wrapper"><img src="images/decoration/decor5.jpg" alt="Content Image"></div>
							</div><!-- col-sm-6 -->
							<div class="col-sm-6">
								<div class="img-wrapper"><img src="images/decoration/dec2.jpg" alt="Content Image"></div>
							</div><!-- col-sm-6 -->
						</div><!-- row -->
						
						<h4 class="margin-top-btm">Wedding Dreamz</h4>
						
						<p class="desc">Wedding ceremony is all about the decorations, food, dress and many other features which make it all attractive to people. 
						Wedding Dreamz concentrate on the major elemnets of the wedding.</p>
						
						<div class="img-wrapper"><img src="images/main1.jpg" alt="Content Image"></div>
						
						<h4 class="margin-top-btm">About the Packages</h4>
					
						<ul class="braidmaids-name">
							<li><u>Catering</u></li>
							<li>Vegetarian</li>
							<li>Non-Vegetarian</li>
							<li>Snacks</li>
							<li>Desserts</li>
						</ul>
						<ul class="braidmaids-name">
							<li><u>Hall Decoration</u></li>
							<li>Stage Decoration</li>
							<li>Floral Decoration</li>
							<li>Lightings</li>
						</ul>
						<ul class="braidmaids-name">
							<li><u>Studio</u></li>
							<li>Elite pack</li>
							<li>Standard pack</li>
							<li>Fairytale pack</li>
							<li>The Legend pack</li>
							<li>The Epic pack</li>
						</ul>
						<ul class="braidmaids-name">
							<li><u>Dress</u></li>
							<li>Groom(Shirt & Dhoties, Suits,Sherwani)</li>
							<li>Bride(Saree,Gown,Lehenga)</li>
						</ul>
					</div><!-- content -->
					
				</div><!-- col-sm-12 -->
			</div><!-- row -->
		</div><!-- container -->
	</section><!-- section -->
	
	<footer>
		<div class="container center-text">
			
			<div class="logo-wrapper">
				<a class="logo" href="#"><img src="images/logo-black.png" alt="Logo Image"></a>
				<i class="icon icon-star"></i>
			</div>
			<br><br><br>
			
			<ul class="footer-links">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php" >GALLERY</a></li>
				<li><a href="register.php">SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul>
			<br>
			<ul class="social-icons">
				<li><a href="#"><i class="icon icon-heart"></i></a></li>
				<li><a href="#"><i class="icon icon-twitter"></i></a></li>
				<li><a href="#"><i class="icon icon-instagram"></i></a></li>
				<li><a href="#"><i class="icon icon-pinterest"></i></a></li>
				<li><a href="#"><i class="icon icon-tripadvisor"></i></a></li>
			</ul><br>

		
		<div></div>
		</div><!-- container -->
	</footer>
	<!-- SCIPTS -->
	<script src="common-js/jquery-3.1.1.min.js"></script>
	<script src="common-js/tether.min.js"></script>
	<script src="common-js/bootstrap.js"></script>
	<script src="common-js/jquery.countdown.min.js"></script>
	<script src="common-js/jquery.fluidbox.min.js"></script>
	<script src="common-js/scripts.js"></script>
	
</body>
</html>