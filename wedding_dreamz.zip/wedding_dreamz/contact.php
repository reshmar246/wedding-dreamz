<?php
include 'conn.php';

?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="common-css/bootstrap.css" rel="stylesheet">
	<link href="common-css/fluidbox.min.css" rel="stylesheet">
	<link href="common-css/font-icon.css" rel="stylesheet">
	<link href="common-css/styles.css" rel="stylesheet">
	<link href="common-css/responsive.css" rel="stylesheet">
	<!--script-->
	 <script src="common-js/mail.js"></script>
</head>
<body>
	<header>
		<div class="container">
			<a class="logo" href="#"><img src="images/logo-white.png" alt="Logo"></a>
			<div class="menu-nav-icon" data-nav-menu="#main-menu"><i class="icon icon-bars"></i></div>
			<ul class="main-menu visible-on-click" id="main-menu">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php" >GALLERY</a></li>
				<li><a href="register.php" >SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul><!-- main-menu -->
		</div><!-- container -->
	</header>
	<div class="main-slider" style="background-image: url(images/hd2.jpeg);">
		<div class="display-table center-text">
			<div class="display-table-cell">
				<div class="slider-content">
				<i class="small-icon icon icon-tie"></i>
					<h3 class="pre-title">Wedding Dreamz</h3>
					<p><h4>Join us as we celebrate life and love.</h3></p>
				</div><!-- slider-content-->
			</div><!--display-table-cell-->
		</div><!-- display-table-->
	</div><!-- main-slider -->
	<section class="contact-area" style="padding:10px;">
		<div class="contact-wrapper section float-left">
			<div class="container">
				<div class="row">
					<div class="col-sm-2"></div>
			<?php
				include 'conn.php';
				$query=mysqli_query($con,"select * from tbl_registration,tbl_login WHERE tbl_login.login_id=tbl_registration.login_id AND tbl_login.login_role=1");
				while ($row=mysqli_fetch_array($query)) {
			?>	
					<div class="col-sm-10">
						<div class="heading">
							<h3 class="title">Contact Us</h3>
							<i class="icon icon-star"></i>
						</div>
						
						<div class="margin-bottom">
							<h5><p style="text-transform:uppercase;font-weight:600;"><?php echo $row['reg_name']?></p>
							<p><?php echo $row['reg_place']?></p></h5><br>
							<h5><?php echo $row['reg_phone']?></h5>
							<h5><?php echo $row['username']?></h5>
													
						</div><!-- margin-bottom -->
					</div><!-- col-sm-10 -->
			
				<?php
					}
				?>		
				</div><!-- row -->
			</div><!-- container -->
		</div><!-- float-left -->
		
		<div class="map-area">
			<div id="map" style="height:100%;"></div>
		</div><!-- map-area -->
		<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB-oEyU88bRR6xcbV1gI_Cahc8ugKC_JPE&callback=initMap"></script>
	
	</section><!-- section -->
	
	<!--footer area-->
	<footer>
		<div class="container center-text">
			
			<div class="logo-wrapper">
				<a class="logo" href="#"><img src="images/logo-black.png" alt="Logo Image"></a>
				<i class="icon icon-star"></i>
			</div>
			<br><br>
			<ul class="footer-links">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php" >GALLERY</a></li>
				<li><a href="register.php">SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul>
			<br>
			<ul class="social-icons">
				<li><a href="#"><i class="icon icon-heart"></i></a></li>
				<li><a href="#"><i class="icon icon-twitter"></i></a></li>
				<li><a href="#"><i class="icon icon-instagram"></i></a></li>
				<li><a href="#"><i class="icon icon-pinterest"></i></a></li>
				<li><a href="#"><i class="icon icon-tripadvisor"></i></a></li>
			</ul><br>
		
		<div></div>
		</div><!-- container -->
	</footer>
	<!-- SCIPTS -->
	<script src="common-js/jquery-3.1.1.min.js"></script>
	<script src="common-js/tether.min.js"></script>
	<script src="common-js/bootstrap.js"></script>
	<script src="common-js/jquery.countdown.min.js"></script>
	<script src="common-js/jquery.fluidbox.min.js"></script>
	<script src="common-js/scripts.js"></script>
	
</body>
</html>