//form submit
$("#regForm").submit(function (e) {
    alert();
    e.preventDefault();
    if (!hasEmptyInvalidFields()) {
        $("#regForm").unbind().submit();
    } else {
        userAlert("Invalid details");
    }
});

//validation
$(".validate").on("blur", function () {
//    alert();
    $optional = false;
    $value = $(this).val();
    $type = $(this).attr("type");
    if ($(this).hasClass("optional")) {
        $optional = true;
    }
    if (!inputValidate($value, $type, $optional)) {
        //input has invalid/empty data
        $(this).addClass("invalid-data");
    } else {
        $(this).removeClass("invalid-data");
    }
});

function inputValidate($value, $type, $optional) {
    if ($value == "" && $optional) {
        return true;
    }
    if ($value == "" && !$optional) {
        return false;
    }
    //regex set for validation
    var pattern;
    $telPattern = /^([0-9]{10})?$/;
    $textPattern = /[A-Za-z0-9]/;
    $pswdPattern = /[\@]{1}/;
    $emailPattern = /\@{1}.{1}/;
    // dd/mm/yyyy
    $datePattern = /^([0-2]{1}[0-9]{1}|[0-3]{1}[0-1]{1}|[0-9]{1})\/([0]{1}[0-9]{1}|[0-1]{1}[0-2]{1}|[0-9]{1})\/([1]{1}[9]{1}[4-9]{1}[0-9]{1}|[2]{1}[0]{1}[0-1]{1}[0-9]{1})/;
    switch ($type) {
        case "number":
            pattern = $number;
            break;
        case "tel":
            pattern = $telPattern;
            break;
        case "text":
            pattern = $textPattern;
            break;
        case "password":
            pattern = $pswdPattern;
            break;
        case "date":
            $value = formatDate($value);
            pattern = $datePattern;
            break;
        case "email":
            pattern = $emailPattern;
            break;
    }
    if (!pattern.test($value)) {
        return false;
    }
    //finally input is valid
    return true;
}

function hasEmptyInvalidFields() {
    $length = $(".validate").length;
    for (i = 0; i < $length; i++) {
        var selector = ".validate:eq(" + i + ")";
        if (
            ($(selector).val() == "" && !$(selector).hasClass("optional")) ||
            $(selector).hasClass("invalid-data")
        ) {
            $(selector).focus();
            // $(selector).addClass("invalid-data");
            $position = $(selector).offset().top;
            $("body, html").animate({
                scrollTop: $position
            });
            return true;
        }
    }
    return false;
    // console.log($(".validate:eq(0)").val());
}

function formatDate($value) {
    var date = new Date($value);
    $date = date.getDate();
    $month = date.getMonth() + 1;
    if ($month < 10) {
        $month = "0" + $month;
    }
    $date += "/" + $month;
    $date += "/" + date.getFullYear();
    return $date;
}

//user alert
function userAlert($message) {
    $(".alert-data").html($message);
    $(".alert-box")
        .fadeIn()
        .delay(4000)
        .fadeOut();
}