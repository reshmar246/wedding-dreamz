$(document).ready(function(){	
  $("#registration").on("submit",function(){
  
    var name= /^[a-zA-Z]*$/;
	var place= /^[a-zA-Z]*$/;
    var mobile= /^[0-9]{9,10}$/;
    var email= /^[A-Za-z0-9._]*\@[A-Za-z0-9._]*\.[A-Za-z]{2,5}$/;
    var username= /^[0-9a-zA-Z]+$/;
    var password= /^[0-9a-zA-Z]+$/;
    //var val_password1= /^[0-9a-zA-Z]+$/;

    $name= $('#name').val();
    $place= $('#place').val();
    $mobile= $('#mobile').val();
    $email= $('#email').val();
    $username=$('#username').val();
    $password= $('#password').val();
    //$password1= $('#password1').val();


    if(!name.test($name)){
      alert("Enter Invalid Name!");
      return false;
    }
    else if (!place.test($place)) {
      alert(" Enter A Valid Place ");
      return false;
    }
    else if (!mobile.test($mobile)) {
      alert("Enter valid Mobile Number");
      return false;
    }
    else if (!email.test($email)) {
      alert("Enter Email");
      return false;
    }
    else if (!username.test($username)) {
      alert("Enter Username");
      return false;
    }
    else if (!password.test($password)) {
      alert("Enter Password");
      return false;
    }
    /*else if (!val_password1.test($password)) {
      alert("enter password1");
      return false;
    }*/
    else {
      return true;
    }
  });
  
  $("#name").focusout(function(){
    var name=  /^[a-zA-Z]*$/;
    $name= $('#name').val();
	if($name == "" ){
		$('#name_error').html(" Enter Name");
		return false;
		}
    else if(!val_name.test($name)){
		$(this).css('border','2px solid red');
		$('#name_error').html("Invalid Name, Name Must be Alphabets Only");
		return false;
        }
    else {
		$(this).css('border','NONE');
		$('#name_error').html("");
      return true;
    }
  });
       
    $("#place").focusout(function(){
    var place=/^[0-9a-zA-Z]+$/;
    $place= $('#place').val();
	if($place == "" ){
		$('#place_error').html(" Enter Place");
		return false;
		}
    else if(!place.test($place)){
		$(this).css('border','2px solid red');
		$('#place_error').html("Invalid Place");
		return false;
    }
    else {
		$(this).css('border','NONE');
		$('#place_error').html("");

      return true;
    }
  });

        $("#mobile").focusout(function(){
		var mobile= /^[0-9]{9,10}$/;
		$mobile= $('#mobile').val();
		if($mobile == "" ){
		$('#mobile_error').html(" Enter Mobile number");
		return false;
		}
		else if(!val_mobile.test($mobile)){
			$(this).css('border','2px solid red');
	  		$('#mobile_error').html("Mobile Number Must Contain Digits Only,Maximum 10 digits including code");
		return false;
		}
		else {
			$(this).css('border','NONE');
			$('#mobile_error').html("");
		return true;
			}
  });
         $("#email").focusout(function(){
			var email= /^[A-Za-z0-9._]*\@[A-Za-z0-9._]*\.[A-Za-z]{2,5}$/;
			$email= $('#email').val();
			if($email == "" ){
			$('#email_error').html(" Enter Email");
			return false;
		}
			
			else if(!val_email.test($email)){
				$(this).css('border','2px solid red');
	  	  		$('#email_error').html("Invalid email , Email must Like abc@gmail.com");	
				return false;
			}
			else {
				$(this).css('border','NONE');
				$('#email_error').html("");
				return true;
			}
	});
		
       $("#username").focusout(function(){
		var username= /^[0-9a-zA-Z]+$/;
		$username= $('#username').val();
		if(!username.test($username)){
			$(this).css('border','2px solid red');
	  	  	$('#username_error').html("Invalid Username ");
		return false;
		}
		else {
			$(this).css('border','NONE');
			$('#username_error').html("");

		return true;
		}
  });
   
		$("#password").focusout(function(){
		var password= /^[0-9a-zA-Z]+$/;
		$password= $('#password').val();
		if(!password.test($password)){
			$(this).css('border','2px solid red');
	  	  	$('#password_error').html("Invalid password ");
		return false;
		}
		else {
			$(this).css('border','NONE');
			$('#password_error').html("");
		return true;
		}
  });
  		/*$("#password1").focusout(function(){
		var val_password1= /^[0-9a-zA-Z]+$/;
		$password1= $('#password1').val();
		if(!val_password1.test($password1)){
			$(this).css('border','2px solid red');
	  	  	$('#password1_error').html(" Password Does't Match");
		return false;
		}
		else {
			$(this).css('border','NONE');
			$('#password1_error').html("");
		return true;
		}
  });*/
  
 });