<?php
	include_once 'conn.php';
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="images/favicon.png" type="image/png">
	<title>Wedding Dreamz</title>
	<!-- Font -->
	<link href="https://fonts.googleapis.com/css?family=Playball%7CBitter" rel="stylesheet">
	<!-- Stylesheets -->
	<link href="common-css/bootstrap.css" rel="stylesheet">
	<link href="common-css/fluidbox.min.css" rel="stylesheet">
	<link href="common-css/font-icon.css" rel="stylesheet">
	<link href="common-css/styles3.css" rel="stylesheet">
	<link href="common-css/responsive.css" rel="stylesheet">
	<link href="css/pack_bootstrap.css" rel="stylesheet">
	<link href="css/pack_style.css" rel="stylesheet">
	<!--script-->
	<!---scripts-->	
    <script src="common-js/jquery.js"></script>
	 <script src="common-js/mail.js"></script>
</head>
<body>
	<header>
		<div class="container">
			<a class="logo" href="#"><img src="images/logo-white.png" alt="Logo"></a>
			<div class="menu-nav-icon" data-nav-menu="#main-menu"><i class="icon icon-bars"></i></div>
			<ul class="main-menu visible-on-click" id="main-menu">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php">GALLERY</a></li>
				<li><a href="register.php" >SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul><!-- main-menu -->
		</div><!-- container -->
	</header>
	<div class="main-slider">
		<div class="display-table center-text">
			<div class="display-table-cell">
				<div class="slider-content">
				<i class="small-icon icon icon-tie"></i>
					<h3 class="pre-title">Wedding Dreamz</h3>
					<p><h4>Join us as we celebrate life and love.</h3></p>
				</div><!-- slider-content-->
				

			</div><!--display-table-cell-->
		</div><!-- display-table-->
	</div><!-- main-slider -->
	

	<!-- Home Slider Nav - Prev -->
			<div class="home_slider_nav home_slider_prev">
				<svg version="1.1" id="Layer_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					width="28px" height="33px" viewBox="0 0 28 33" enable-background="new 0 0 28 33" xml:space="preserve">
					<defs>
						<linearGradient id='home_grad_prev'>
							<stop offset='0%' stop-color='#fa9e1b'/>
							<stop offset='100%' stop-color='#8d4fff'/>
						</linearGradient>
					</defs>
					<path class="nav_path" fill="#F3F6F9" d="M19,0H9C4.029,0,0,4.029,0,9v15c0,4.971,4.029,9,9,9h10c4.97,0,9-4.029,9-9V9C28,4.029,23.97,0,19,0z
					M26,23.091C26,27.459,22.545,31,18.285,31H9.714C5.454,31,2,27.459,2,23.091V9.909C2,5.541,5.454,2,9.714,2h8.571
					C22.545,2,26,5.541,26,9.909V23.091z"/>
					<polygon class="nav_arrow" fill="#F3F6F9" points="15.044,22.222 16.377,20.888 12.374,16.885 16.377,12.882 15.044,11.55 9.708,16.885 11.04,18.219 
					11.042,18.219 "/>
				</svg>
			</div>
			
			<!-- Home Slider Nav - Next -->
			<div class="home_slider_nav home_slider_next">
				<svg version="1.1" id="Layer_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="28px" height="33px" viewBox="0 0 28 33" enable-background="new 0 0 28 33" xml:space="preserve">
					<defs>
						<linearGradient id='home_grad_next'>
							<stop offset='0%' stop-color='#fa9e1b'/>
							<stop offset='100%' stop-color='#8d4fff'/>
						</linearGradient>
					</defs>
				<path class="nav_path" fill="#F3F6F9" d="M19,0H9C4.029,0,0,4.029,0,9v15c0,4.971,4.029,9,9,9h10c4.97,0,9-4.029,9-9V9C28,4.029,23.97,0,19,0z
				M26,23.091C26,27.459,22.545,31,18.285,31H9.714C5.454,31,2,27.459,2,23.091V9.909C2,5.541,5.454,2,9.714,2h8.571
				C22.545,2,26,5.541,26,9.909V23.091z"/>
				<polygon class="nav_arrow" fill="#F3F6F9" points="13.044,11.551 11.71,12.885 15.714,16.888 11.71,20.891 13.044,22.224 18.379,16.888 17.048,15.554 
				17.046,15.554 "/>
				</svg>
			</div>


			
	<section class="section story-area center-text">
		<div class="container">
			<div class="row">
				<div class="col-sm-1"></div>
				<div class="col-sm-10">
					
					<div class="heading">
						<h2 class="title">Our Story</h2>
						<span class="heading-bottom"><i class="icon icon-star"></i></span>
					</div>

					<p class="desc margin-bottom">Every bride and groom wants an incomparable wedding combined with fantasy 
					and style. We create stunning, one-of-a-kind events produced and styled to perfection. 
					From traditional to modern, elegant and relaxed, we focus on any event we plan.</p>
					
				</div><!-- col-sm-10 -->
			</div><!-- row -->
		</div><!-- container -->
	</section><!-- section -->
	
	
	<!-- Start information Area -->

			<section class="section-gap info-area">
				<div class="container3">				
					<div class="single-info row mt-80">
						<div class="col-lg-6 col-md-12 text-center no-padding">
							<div class="info-thumb">
								<img src="images/decoration/dec1.jpg" class="img-fluid" alt="">
							</div>
						</div>
						<div class="col-lg-6 col-md-12 mt-60 no-padding">
							<div class="info-content">
								<h1>Hall Decoration</h1>
								<p>The stage takes centrepiece at many Indian wedding functions, and as such, it is probably the single most element to get right when it comes to wedding decor. 
								Perhaps more important than even that is the fact that the stage is the designated area where the rituals that unite two souls take place, and for this reason as well, they assume a prime importance in all wedding decorations. 
								</p>
								<div class="meta">
									<p><b style="color:black;">Packages:</b>  Stage Decoration, Lightings, Floral Decoration</p>
								</div>
							</div>
						</div>
					</div>
					<div class="single-info row mt-50">
						<div class="col-lg-6 col-md-12 mt-60 no-padding">
							<div class="info-content2">
								<h1>Studio</h1>
								<p>We specialise in a fun, off-beat and candid style of wedding photography and guarantee memories from your wedding that will last a lifetime. 
								We are proud to be amongst the photographers who defined this genre and offer everything you need to make your wedding memories eternal. </p>
								<div class="meta">
									<p><b style="color:black;">Packages:</b>  Elite pack, Standard pack, Fairytale pack, The Legend pack, The Epic pack</p>
								</div>
							</div>
						</div>	
						<div class="col-lg-6 col-md-12 text-center no-padding">
							<div class="info-thumb">
								<img src="images/studio/img7.jpg" class="img-fluid" alt="">
							</div>
						</div>											
					</div>
					<div class="single-info row mt-80">
						<div class="col-lg-6 col-md-12 text-center no-padding">
							<div class="info-thumb">
								<img src="images/food/cater2.jpg" class="img-fluid" alt="">
							</div>
						</div>
						<div class="col-lg-6 col-md-12 mt-60 no-padding">
							<div class="info-content">
								<h1>Catering</h1>
								<p>In catering, we offer many items beyond our restaurants menu and on our website, including all kinds of regional Indian items. 
								All our chefs need is outdoor space or an open garage to set up the tandoor oven. 
								From grinding our own spices to making yogurt and cheese, we prepare everything from scratch. </p>
								<div class="meta">
									<p><b style="color:black;">Packages:</b>  Vegetarian, Non-Vegetarian, Snacks, Sweets & Dessert</p>
								</div>
							</div>
						</div>
					</div>
					<div class="single-info row mt-50">
						<div class="col-lg-6 col-md-12 mt-60 no-padding">
							<div class="info-content2">
								<h1>Dress</h1>
								<p>Weddings in India vary regionally, the religion and per personal preferences of the bride and groom. 
								The dress of bride and groom will be the most attractive part in the wedding ceremony.</p>
								<div class="meta">
									<p><b style="color:black;">Packages:</b>  Groom(Shirt & Dhoties, Suits,Sherwani) and Bride(Saree,Gown,Lehenga)</p>
								</div>
							</div>
						</div>	
						<div class="col-lg-6 col-md-12 text-center no-padding">
							<div class="info-thumb">
								<img src="images/studio/photo5.jpg" class="img-fluid" alt="">
							</div>
						</div>											
					</div>
				</div>
			</section>			
			<!-- End information Area -->
	
		
	
	<section class="section ceremony-area center-text">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					
					<div class="heading">
						<h2 class="title">Wedding</h2>
						<span class="heading-bottom"><i class="color-white icon icon-star"></i></span>
					</div>

					<div class="ceremony margin-bottom">
						<p class="desc">We assist our clients in creating memorable, magical 
						celebrations that exceed expectations. Our personal approach ensures the weddings we 
						plan are meaningful and truly reflect our clients as individuals, as couples, and states 
						something about their shared values and sense of style.</p>
						
					</div>
					
				</div><!-- col-sm-10 -->
			</div><!-- row -->
		</div><!-- container -->
	</section><!-- section -->
	
	
	
	
	
	<footer>
		<div class="container center-text">
			
			<div class="logo-wrapper">
				<a class="logo" href="#"><img src="images/logo-black.png" alt="Logo Image"></a>
				<i class="icon icon-star"></i>
			</div>
			<br><br><br>
			
			<ul class="footer-links">
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php" >ABOUT</a></li>
				<li><a href="gallery.php" >GALLERY</a></li>
				<li><a href="register.php">SIGNUP</a></li>
				<li><a href="signin.php" >SIGNIN</a></li>
				<li><a href="contact.php" >CONTACT</a></li>
			</ul>
			<br>
			<ul class="social-icons">
				<li><a href="#"><i class="icon icon-heart"></i></a></li>
				<li><a href="#"><i class="icon icon-twitter"></i></a></li>
				<li><a href="#"><i class="icon icon-instagram"></i></a></li>
				<li><a href="#"><i class="icon icon-pinterest"></i></a></li>
				<li><a href="#"><i class="icon icon-tripadvisor"></i></a></li>
			</ul><br>

		
		<div></div>
		</div><!-- container -->
	</footer>
	<!-- SCIPTS -->
	<script src="common-js/jquery-3.1.1.min.js"></script>
	<script src="common-js/tether.min.js"></script>
	<script src="common-js/bootstrap.js"></script>
	<script src="common-js/jquery.countdown.min.js"></script>
	<script src="common-js/jquery.fluidbox.min.js"></script>
	<script src="common-js/scripts.js"></script>
	
</body>
</html>